# -*- coding: utf-8 -*-
# Wordt gestart als je de add-on zelf opent: toont direct de laatste info.
from resources.lib import updater

updater.run_check(manual=True)

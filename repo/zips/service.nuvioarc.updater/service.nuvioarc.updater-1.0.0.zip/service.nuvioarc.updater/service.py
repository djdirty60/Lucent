# -*- coding: utf-8 -*-
import xbmc
from resources.lib import updater

monitor = xbmc.Monitor()

# Even wachten tot Kodi (en Seren) helemaal is opgestart.
if not monitor.waitForAbort(45):
    if updater.get_bool("check_on_start", True):
        updater.run_check(manual=False)
    while not monitor.abortRequested():
        if monitor.waitForAbort(updater.interval_hours() * 3600):
            break
        updater.run_check(manual=False)

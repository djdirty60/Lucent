# -*- coding: utf-8 -*-
"""Lucent: the choices in the skin settings that need a list or a Kodi setting.

RunScript(special://skin/scripts/settings.py,<what>)
  sync        read Kodi's own settings into the labels of the skin settings page
  accent      colour theme            amoled      pure black surfaces (toggle)
  zoom        interface scale         ssdim       dim when idle (toggle)
  sstime      idle timeout            sslevel     dim strength
  landscape   landscape cards on Home watched     show / dim watched titles
  glow        edge glow on focused cards
  logos       where to put your own rating logos
  pauseinfo   pause screen delay      flags       own picture / sound logos
  reset       restore all skin settings
"""
import json
import sys

import xbmc
import xbmcaddon
import xbmcgui
import xbmcvfs

HEADING = "Lucent"
_NL = xbmc.getLanguage(xbmc.ISO_639_1) == "nl"
DIM = "screensaver.xbmc.builtin.dim"
LOGO_DIR = "special://profile/addon_data/skin.lucent/logos/"
FLAG_DIR = "special://profile/addon_data/skin.lucent/flags/"
FLAG_KEYS = ['8k', '4k', '1080', '720', 'sd', 'dolbyvision', 'hdr10plus', 'hdr10', 'hlg', 'hevc', 'av1', 'h264', 'vp9', 'atmos', 'dtsx', 'truehd', 'dtshd_ma', 'dtshd_hra', 'dts', 'eac3', 'ac3', 'aac', 'flac', 'opus', 'pcm', 'mp3', '71', '61', '51', '20', '10']


def tr(pair, *args):
    text = pair[1 if _NL else 0]
    return text.format(*args) if args else text


ACCENTS = [  # id, (en, nl)   — names as in Nuvio
    ("glass", ("Glass", "Glas")), ("white", ("White", "Wit")), ("crimson", ("Crimson", "Karmozijn")),
    ("emerald", ("Emerald", "Smaragd")), ("ocean", ("Ocean", "Oceaan")), ("violet", ("Violet", "Violet")),
    ("amber", ("Amber", "Amber")), ("gold", ("Gold", "Goud")), ("rose", ("Rose", "Roze")),
    ("rosegold", ("Rose Gold", "Roségoud")), ("copper", ("Copper", "Koper")), ("jade", ("Jade", "Jade")),
    ("arcticblue", ("Arctic Blue", "Arctisch blauw")), ("graphite", ("Graphite", "Grafiet")),
]
ZOOM = [-10, -6, -4, -2, 0, 2, 4, 6, 10]
SS_TIMES = [1, 2, 3, 5, 10, 15, 30]
SS_LEVELS = [(60, ("Gentle – the screen stays clearly visible", "Zacht – scherm blijft goed zichtbaar")),
             (30, ("Balanced – dark but readable", "Gebalanceerd – donker maar leesbaar")),
             (10, ("Strong – barely visible", "Sterk – nauwelijks zichtbaar"))]
LANDSCAPE = [("", ("Off", "Uit")), ("home", ("Home only", "Alleen startscherm"))]
WATCHED = [("", ("Show", "Tonen")), ("dim", ("Dim", "Dimmen"))]
WATCHED_COLOURS = [("", ("Red", "Rood")), ("graphite", ("Graphite", "Grafiet")), ("white", ("White", "Wit")),
                   ("green", ("Green", "Groen")), ("blue", ("Blue", "Blauw")), ("gold", ("Gold", "Goud"))]


def watched_label():
    """'Show  ·  check: Graphite' for the row in Skin settings."""
    shown = tr(dict(WATCHED).get(skin_string("nuvio.watched"), WATCHED[0][1]))
    colour = tr(dict(WATCHED_COLOURS).get(skin_string("lucent.watched.colour"), WATCHED_COLOURS[0][1]))
    set_string("nuvio.watched.label", f"{shown}  ·  {tr(('check', 'vinkje'))}: {colour}")


def pick_watched():
    """Watched titles: show or dim them, and the colour of the check on the poster (issue #10)."""
    while True:
        colour = tr(dict(WATCHED_COLOURS).get(skin_string("lucent.watched.colour"), WATCHED_COLOURS[0][1]))
        rows = [tr(n) for _v, n in WATCHED] + [tr(("Colour of the check: {0}", "Kleur van het vinkje: {0}")).format(colour)]
        current = [v for v, _n in WATCHED].index(skin_string("nuvio.watched")) if skin_string("nuvio.watched") in ("", "dim") else 0
        choice = choose(tr(("Watched titles", "Bekeken titels")), rows, current)
        if choice < 0:
            break
        if choice < len(WATCHED):
            set_string("nuvio.watched", WATCHED[choice][0])
            watched_label()
            break
        values = [v for v, _n in WATCHED_COLOURS]
        now = skin_string("lucent.watched.colour")
        pick = choose(tr(("Colour of the check", "Kleur van het vinkje")), [tr(n) for _v, n in WATCHED_COLOURS],
                      values.index(now) if now in values else 0)
        if pick >= 0:
            set_string("lucent.watched.colour", values[pick])
        watched_label()
PAUSE = [("3", ("After 3 seconds", "Na 3 seconden")), ("", ("After 5 seconds", "Na 5 seconden")),
         ("10", ("After 10 seconds", "Na 10 seconden")), ("15", ("After 15 seconds", "Na 15 seconden")),
         ("30", ("After 30 seconds", "Na 30 seconden")), ("60", ("After 1 minute", "Na 1 minuut")),
         ("off", ("Off", "Uit")),
         ("clean3", ("Info first, clean picture after 3 seconds", "Eerst info, leeg beeld na 3 seconden")),
         ("clean5", ("Info first, clean picture after 5 seconds", "Eerst info, leeg beeld na 5 seconden")),
         ("clean10", ("Info first, clean picture after 10 seconds", "Eerst info, leeg beeld na 10 seconden"))]
OSDCLOSE = [("", ("Never (Back closes it)", "Nooit (Terug sluit het)")), ("3", ("After 3 seconds", "Na 3 seconden")),
            ("5", ("After 5 seconds", "Na 5 seconden")), ("8", ("After 8 seconds", "Na 8 seconden")),
            ("10", ("After 10 seconds", "Na 10 seconden")), ("15", ("After 15 seconds", "Na 15 seconden"))]
POSTERFOCUS = [("", ("Off", "Uit")), ("window", ("Trailer window with soft edge", "Trailervenster met zachte rand")),
               ("hero", ("Hero media", "Hero-media")), ("expand", ("Expanded card", "Uitgevouwen kaart"))]
TRAILER_DELAY = [("1", ("After 1 second", "Na 1 seconde")), ("", ("After 2 seconds", "Na 2 seconden")),
                 ("3", ("After 3 seconds", "Na 3 seconden")), ("5", ("After 5 seconds", "Na 5 seconden")),
                 ("8", ("After 8 seconds", "Na 8 seconden"))]
GLOW = [("off", ("Off", "Uit")), ("subtle", ("Subtle", "Subtiel")), ("", ("Balanced", "Gebalanceerd")),
        ("bold", ("Bold", "Sterk"))]


# ----------------------------------------------------------------------------- helpers
def jsonrpc(method, params):
    request = {"jsonrpc": "2.0", "id": 1, "method": method, "params": params}
    try:
        return json.loads(xbmc.executeJSONRPC(json.dumps(request))).get("result")
    except Exception as error:  # noqa: BLE001
        xbmc.log(f"[skin.lucent] settings.py {method}: {error}", xbmc.LOGWARNING)
        return None


def kodi_get(setting):
    result = jsonrpc("Settings.GetSettingValue", {"setting": setting}) or {}
    return result.get("value")


def kodi_set(setting, value):
    return jsonrpc("Settings.SetSettingValue", {"setting": setting, "value": value})


def skin_string(name):
    return xbmc.getInfoLabel(f"Skin.String({name})")


def set_string(name, value):
    """Only write when it really changes: every write makes Kodi save all skin settings to disk."""
    if skin_string(name) == (value or ""):
        return
    if value:
        xbmc.executebuiltin(f'Skin.SetString({name},"{value}")', True)
    else:
        xbmc.executebuiltin(f"Skin.Reset({name})", True)


def set_bool(name, on):
    if bool(xbmc.getCondVisibility(f"Skin.HasSetting({name})")) == bool(on):
        return
    xbmc.executebuiltin(f"Skin.SetBool({name})" if on else f"Skin.Reset({name})", True)


def has(name):
    return xbmc.getCondVisibility(f"Skin.HasSetting({name})")


def choose(heading, labels, current):
    preselect = current if 0 <= current < len(labels) else -1
    return xbmcgui.Dialog().select(heading, labels, preselect=preselect)


# ----------------------------------------------------------------------------- colour theme
def apply_colours():
    accent = skin_string("nuvio.accent") or "glass"
    name = accent + ("-amoled" if has("nuvio.amoled") else "")
    value = "SKINDEFAULT" if name == "glass" else name
    if kodi_get("lookandfeel.skincolors") != value:
        kodi_set("lookandfeel.skincolors", value)  # Kodi reloads the skin by itself


def pick_accent():
    ids = [a for a, _n in ACCENTS]
    current = skin_string("nuvio.accent") or "glass"
    choice = choose(tr(("Colour theme", "Kleurthema")), [tr(n) for _a, n in ACCENTS], ids.index(current) if current in ids else 0)
    if choice < 0:
        return
    accent, name = ACCENTS[choice]
    set_string("nuvio.accent", "" if accent == "glass" else accent)
    set_string("nuvio.accent.label", tr(name))
    apply_colours()


def toggle_amoled():
    set_bool("nuvio.amoled", not has("nuvio.amoled"))
    apply_colours()


# ----------------------------------------------------------------------------- interface scale
def zoom_label(value):
    return tr(("Standard", "Standaard")) if value == 0 else f"{value:+d}%"


def pick_zoom():
    current = kodi_get("lookandfeel.skinzoom") or 0
    labels = [zoom_label(z) for z in ZOOM]
    choice = choose(tr(("Interface scale", "Schaal van de interface")), labels, ZOOM.index(current) if current in ZOOM else 4)
    if choice >= 0:
        set_string("nuvio.zoom.label", labels[choice])
        kodi_set("lookandfeel.skinzoom", ZOOM[choice])


# ----------------------------------------------------------------------------- screensaver
def toggle_dim():
    on = kodi_get("screensaver.mode") == DIM
    kodi_set("screensaver.mode", "" if on else DIM)
    set_bool("nuvio.ss.dim", not on)


def pick_time():
    current = kodi_get("screensaver.time") or 3
    labels = [tr(("{0} minutes", "{0} minuten"), m) if m > 1 else tr(("1 minute", "1 minuut")) for m in SS_TIMES]
    choice = choose(tr(("Idle timeout", "Wachttijd")), labels, SS_TIMES.index(current) if current in SS_TIMES else -1)
    if choice >= 0:
        kodi_set("screensaver.time", SS_TIMES[choice])
        set_string("nuvio.ss.time.label", labels[choice])


def pick_level():
    try:
        addon = xbmcaddon.Addon(DIM)
        current = int(addon.getSetting("level") or 20)
    except Exception:  # noqa: BLE001
        return
    levels = [lv for lv, _n in SS_LEVELS]
    nearest = min(range(len(levels)), key=lambda i: abs(levels[i] - current))
    choice = choose(tr(("Dim strength", "Dimsterkte")), [tr(n) for _l, n in SS_LEVELS], nearest)
    if choice >= 0:
        addon.setSetting("level", str(levels[choice]))
        set_string("nuvio.ss.level.label", tr(SS_LEVELS[choice][1]).split(" – ")[0])


# ----------------------------------------------------------------------------- simple lists
def pick_option(name, options, heading):
    values = [v for v, _n in options]
    current = skin_string(name)
    choice = choose(heading, [tr(n) for _v, n in options], values.index(current) if current in values else 0)
    if choice >= 0:
        set_string(name, values[choice])
        set_string(name + ".label", tr(options[choice][1]))


# ----------------------------------------------------------------------------- logos
LOGO_URL = "https://raw.githubusercontent.com/djdirty60/Lucent/main/logos/"
LOGO_NAMES = ("imdb", "tmdb", "trakt", "rt", "rt_rotten", "rta", "rta_spilt", "mc", "mcu", "lb")


def scan_logos():
    """Window(home).Property(nuvio.logo.<name>) for the rating logos you have (used on Home and the info page)."""
    home = xbmcgui.Window(10000)
    for name in LOGO_NAMES:
        path = f"{LOGO_DIR}{name}.png"
        home.setProperty(f"nuvio.logo.{name}", path if xbmcvfs.exists(path) else "")


def fetch_logos():
    """Copy the rating logos of the Lucent GitHub page to the logo folder. Returns how many were saved."""
    import urllib.request
    saved = 0
    for name in LOGO_NAMES:
        try:
            req = urllib.request.Request(LOGO_URL + name + ".png", headers={"User-Agent": "Kodi skin.lucent"})
            with urllib.request.urlopen(req, timeout=10) as resp:
                data = resp.read()
            if data[:8] != b"\x89PNG\r\n\x1a\n":
                continue
            with xbmcvfs.File(f"{LOGO_DIR}{name}.png", "wb") as fh:
                fh.write(bytearray(data))
            saved += 1
        except Exception:  # noqa: BLE001 - this logo is not there
            continue
    scan_logos()
    return saved


def explain_logos():
    if not xbmcvfs.exists(LOGO_DIR):
        xbmcvfs.mkdirs(LOGO_DIR)
    if xbmcgui.Dialog().yesno(HEADING, tr((
            "Fetch the rating logos from the Lucent page on GitHub (github.com/djdirty60/Lucent, folder logos)?",
            "De beoordelingslogo's ophalen van de Lucent-pagina op GitHub (github.com/djdirty60/Lucent, map logos)?")),
            nolabel=tr(("Own logos", "Eigen logo's")), yeslabel=tr(("Fetch", "Ophalen"))):
        n = fetch_logos()
        xbmcgui.Dialog().notification(HEADING, tr(("{0} logos saved", "{0} logo's opgeslagen"), n), xbmcgui.NOTIFICATION_INFO, 5000)
        return
    real = xbmcvfs.translatePath(LOGO_DIR)
    xbmcgui.Dialog().ok(HEADING, tr((
        "Put your own logos (PNG, best about 3:1 wide) in this folder:[CR][B]{0}[/B][CR]"
        "imdb, tmdb, trakt, rt (Rotten Tomatoes), rta (RT audience), mc (Metacritic), mcu (Metacritic users) and "
        "lb (Letterboxd), each as name.png. The lists and the info page then show the logo instead of the dot and name.",
        "Zet je eigen logo's (PNG, het liefst ongeveer 3:1 breed) in deze map:[CR][B]{0}[/B][CR]"
        "imdb, tmdb, trakt, rt (Rotten Tomatoes), rta (RT-publiek), mc (Metacritic), mcu (Metacritic-gebruikers) en "
        "lb (Letterboxd), elk als naam.png. De lijsten en de infopagina tonen dan het logo in plaats van het bolletje en "
        "de naam."), real))


def scan_flags():
    """Remember which own picture / sound logos exist (shown on the pause screen)."""
    for key in FLAG_KEYS:
        path = FLAG_DIR + key + ".png"
        value = path if xbmcvfs.exists(path) else ""
        if skin_string("nuvio.flag." + key) != value:
            set_string("nuvio.flag." + key, value)


def explain_flags():
    if not xbmcvfs.exists(FLAG_DIR):
        xbmcvfs.mkdirs(FLAG_DIR)
    real = xbmcvfs.translatePath(FLAG_DIR)
    xbmcgui.Dialog().textviewer(HEADING, tr((
        "Put your own logos (PNG, preferably white on transparent) in this folder:[CR][B]{0}[/B][CR][CR]"
        "Use these file names:[CR]{1}[CR][CR]The pause screen then shows your logo instead of the built-in badge. "
        "Open the skin settings once more after adding files.",
        "Zet je eigen logo's (PNG, het liefst wit op transparant) in deze map:[CR][B]{0}[/B][CR][CR]"
        "Gebruik deze bestandsnamen:[CR]{1}[CR][CR]Het pauzescherm toont dan jouw logo in plaats van het ingebouwde label. "
        "Open de skin-instellingen nog een keer nadat je bestanden hebt toegevoegd."),
        real, ", ".join(k + ".png" for k in FLAG_KEYS)))
    scan_flags()


def pick_posterfocus():
    set_bool("nuvio.trailers.menu", True)          # poster trailers are back (they were switched off while they did not work on CoreELEC)
    pick_option("nuvio.posterfocus", POSTERFOCUS, tr(("Trailer on focus", "Trailer bij focus")))
    if skin_string("nuvio.posterfocus"):
        if not xbmc.getCondVisibility("System.HasAddon(plugin.video.youtube)"):
            xbmc.executebuiltin("InstallAddon(plugin.video.youtube)", True)
        # the trailer helper runs from the Home screen; start it now (it quits if it already runs)
        xbmc.executebuiltin("RunScript(special://skin/scripts/trailers.py)")


# ----------------------------------------------------------------------------- sync + reset
def sync():
    """Fill the labels of the settings page from Kodi's own settings."""
    zoom = kodi_get("lookandfeel.skinzoom") or 0
    set_string("nuvio.zoom.label", zoom_label(zoom))
    set_bool("nuvio.ss.dim", kodi_get("screensaver.mode") == DIM)
    minutes = kodi_get("screensaver.time") or 3
    set_string("nuvio.ss.time.label", tr(("{0} minutes", "{0} minuten"), minutes) if minutes > 1 else tr(("1 minute", "1 minuut")))
    try:
        level = int(xbmcaddon.Addon(DIM).getSetting("level") or 20)
        nearest = min(SS_LEVELS, key=lambda item: abs(item[0] - level))
        set_string("nuvio.ss.level.label", tr(nearest[1]).split(" – ")[0])
    except Exception:  # noqa: BLE001
        pass
    accent = skin_string("nuvio.accent") or "glass"
    set_string("nuvio.accent.label", tr(dict(ACCENTS).get(accent, ACCENTS[0][1])))
    scan_flags()
    for name, options in (("nuvio.landscape", LANDSCAPE), ("nuvio.watched", WATCHED), ("nuvio.glow", GLOW),
                          ("nuvio.pauseinfo", PAUSE), ("nuvio.posterfocus", POSTERFOCUS), ("lucent.osdclose", OSDCLOSE),
                          ("nuvio.trailer.delay", TRAILER_DELAY)):
        set_string(name + ".label", tr(dict(options).get(skin_string(name), options[0][1])))
    watched_label()


def reset_all():
    if xbmcgui.Dialog().yesno(HEADING, tr(("Restore all skin settings? Your menu and widgets stay as they are.",
                                           "Alle skin-instellingen herstellen? Je menu en widgets blijven zoals ze zijn."))):
        for name in ("nuvio.accent", "nuvio.accent.label", "nuvio.landscape", "nuvio.watched", "lucent.watched.colour", "nuvio.glow",
                     "nuvio.pauseinfo", "nuvio.posterfocus", "nuvio.trailer.delay", "lucent.osdclose"):
            set_string(name, "")
        for name in ("nuvio.amoled", "nuvio.posterlabels.hide", "nuvio.sideicons.hide", "nuvio.fulldate",
                     "nuvio.fullbackdrop", "nuvio.info.hideratings", "nuvio.info.hidetrailer", "nuvio.hideclock",
                     "nuvio.pauseinfo.hideflags"):
            set_bool(name, False)
        kodi_set("lookandfeel.skinzoom", 0)
        apply_colours()
        sync()


def total_memory_mb():
    """Memory of the box in MB (0 when unknown)."""
    try:
        with open("/proc/meminfo") as fh:
            for line in fh:
                if line.startswith("MemTotal:"):
                    return int(line.split()[1]) // 1024
    except Exception:  # noqa: BLE001 - not Linux / Android without access
        pass
    digits = "".join(ch for ch in xbmc.getInfoLabel("System.Memory(total)") if ch.isdigit())
    return int(digits) if digits else 0


def lite_check():
    """Once: boxes with 2 GB of memory or less get the light mode (fewer helpers, fewer rows, no snow)."""
    mb = total_memory_mb()
    xbmc.executebuiltin('Skin.SetString(lucent.lite.checked,"%d")' % (mb or 1))
    if 0 < mb <= 2600 and not xbmc.getCondVisibility("Skin.HasSetting(lucent.lite)"):
        xbmc.executebuiltin("Skin.SetBool(lucent.lite)")
        xbmc.log(f"[skin.lucent] {mb} MB memory: light mode switched on", xbmc.LOGINFO)


def lite_build():
    """Light mode does not build widgets 7-10 at all; Home is kept in memory, so the skin reloads once when it changes."""
    lite = xbmc.getCondVisibility("Skin.HasSetting(lucent.lite)")
    built = bool(xbmc.getInfoLabel("Skin.String(lucent.lite.built)"))
    if lite == built:
        return
    xbmc.executebuiltin('Skin.SetString(lucent.lite.built,"1")' if lite else "Skin.Reset(lucent.lite.built)")
    xbmc.log(f"[skin.lucent] light mode {'on' if lite else 'off'}: reloading the skin", xbmc.LOGINFO)
    xbmc.sleep(300)
    xbmcgui.Window(10000).setProperty("lucent.helper.stop", "1")
    xbmcgui.Window(10000).clearProperty("nuvio.started")
    xbmc.executebuiltin("ReloadSkin()")


def kodi_more():
    """Settings > System > More Kodi settings: Kodi's own setting pages that are not in Lucent's menu."""
    pages = [(("Music player", "Muziekspeler"), "PlayerSettings,musicplayer"), (("Discs (DVD, Blu-ray)", "Schijven (dvd, Blu-ray)"), "PlayerSettings,discs"),
             (("Pictures and slideshow", "Foto's en diavoorstelling"), "PlayerSettings,pictures"), (("Music library", "Muziekbibliotheek"), "MediaSettings,music"),
             (("Picture library", "Fotobibliotheek"), "MediaSettings,pictures"), (("Services: name and zeroconf", "Diensten: naam en zeroconf"), "ServiceSettings,general"),
             (("UPnP / DLNA", "UPnP / DLNA"), "ServiceSettings,upnp"), (("AirPlay", "AirPlay"), "ServiceSettings,airplay"),
             (("Windows network (SMB)", "Windows-netwerk (SMB)"), "ServiceSettings,smb"), (("Skin, zoom and sounds", "Skin, zoom en geluiden"), "InterfaceSettings,skin"),
             (("Games", "Games"), "GameSettings")]
    pick = xbmcgui.Dialog().select(tr(("More Kodi settings", "Meer Kodi-instellingen")), [tr(n) for n, _w in pages])
    if pick >= 0:
        xbmc.executebuiltin(f"ActivateWindow({pages[pick][1]})")


if __name__ == "__main__":
    what = sys.argv[1] if len(sys.argv) > 1 else "sync"
    {
        "sync": sync, "accent": pick_accent, "amoled": toggle_amoled, "zoom": pick_zoom,
        "ssdim": toggle_dim, "sstime": pick_time, "sslevel": pick_level, "logos": explain_logos,
        "landscape": lambda: pick_option("nuvio.landscape", LANDSCAPE, tr(("Landscape posters", "Liggende posters"))),
        "watched": pick_watched,
        "glow": lambda: pick_option("nuvio.glow", GLOW, tr(("Edge glow", "Randgloed"))),
        "pauseinfo": lambda: pick_option("nuvio.pauseinfo", PAUSE, tr(("Show info after", "Info tonen na"))),
        "osdclose": lambda: pick_option("lucent.osdclose", OSDCLOSE, tr(("Close the player menu by itself", "Spelermenu vanzelf sluiten"))),
        "flags": explain_flags,
        "posterfocus": pick_posterfocus,
        "trailerdelay": lambda: pick_option("nuvio.trailer.delay", TRAILER_DELAY, tr(("Start trailer after", "Trailer starten na"))),
        "reset": reset_all,
        "litecheck": lite_check,
        "litebuild": lite_build,
        "scanlogos": scan_logos,
        "kodimore": kodi_more,
    }.get(what, sync)()

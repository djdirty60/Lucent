# -*- coding: utf-8 -*-
"""Lucent: setup assistant - the most important settings and logins, step by step.

    RunScript(special://skin/scripts/setup.py)          open it (Settings > Lucent > Setup assistant)
    RunScript(special://skin/scripts/setup.py,first)    from Home: only the very first time (Skin.String lucent.setup.done)

Every step says what it is for, shows how it stands right now (green tick / orange note) and has buttons that set it
up. The state is looked at again every two seconds, so after linking Trakt or installing an add-on the tick appears
by itself. Nothing is required: every step can be skipped, and the assistant can be opened again later.
"""
import json
import sys
import threading

import xbmc
import xbmcaddon
import xbmcgui

NL = xbmc.getLanguage(xbmc.ISO_639_1) == "nl"
DONE = "lucent.setup.done"
SEREN = "plugin.video.seren"
IPTV = "pvr.iptvsimple"
LV = "plugin.video.lucent"        # Lucent Video: works best with the skin (rows, info page, library, subtitles)
GREEN, ORANGE, GREY = "FF4CC38A", "FFE8A33D", "FF8A96A3"


def t(en, nl):
    return nl if NL else en


def log(text):
    xbmc.log(f"[skin.lucent] setup: {text}", xbmc.LOGINFO)


def cond(text):
    return xbmc.getCondVisibility(text)


def rpc(method, params=None):
    request = {"jsonrpc": "2.0", "id": 1, "method": method, "params": params or {}}
    try:
        return json.loads(xbmc.executeJSONRPC(json.dumps(request))).get("result")
    except Exception as error:  # noqa: BLE001
        log(f"{method}: {error}")
        return None


def setting(addon_id, key):
    try:
        return xbmcaddon.Addon(addon_id).getSetting(key)
    except Exception:  # noqa: BLE001 - not installed
        return ""


def has(addon_id):
    return cond(f"System.HasAddon({addon_id})")


def install(addon_id):
    xbmc.executebuiltin(f"InstallAddon({addon_id})")


def run(builtin):
    xbmc.executebuiltin(builtin)


# ----------------------------------------------------------------------------- the steps
# each: key, icon, title, body, status() -> (state 'ok' | 'todo' | 'info', text), actions() -> [(label, function)]

def st_welcome():
    return "info", ""


def ac_welcome():
    return []


def no_seren():
    return cond("Skin.HasSetting(lucent.noseren)")


def choose_menu(question):
    """Offer the default menu that fits the choice (with or without Seren)."""
    if xbmcgui.Dialog().yesno("Lucent", question):
        import menu
        m = menu.Menu()
        m.set_defaults()
        m.save()
        xbmcgui.Dialog().notification("Lucent", t("Menu set up", "Menu klaargezet"), "", 3000, False)


def seren_off():
    """'No, without Seren': the Seren choices leave the menu editor and the setup, and the menu can go without Seren."""
    run("Skin.SetBool(lucent.noseren)")
    xbmc.sleep(200)
    choose_menu(t("Lucent now leaves out the Seren choices.\n\nAlso set up the menu without Seren (your Kodi library, search, "
                  "add-ons and favourites)? Your own tabs and widgets are replaced.",
                  "Lucent laat de Seren-keuzes nu weg.\n\nOok het menu zonder Seren klaarzetten (je Kodi-bibliotheek, zoeken, "
                  "add-ons en favorieten)? Je eigen tabs en widgets worden vervangen."))


def seren_on():
    run("Skin.Reset(lucent.noseren)")
    xbmc.sleep(200)
    if has(SEREN):
        choose_menu(t("Also set up the menu with Seren (search, movies and series from Seren)? Your own tabs and widgets are replaced.",
                      "Ook het menu met Seren klaarzetten (zoeken, films en series uit Seren)? Je eigen tabs en widgets worden vervangen."))


def st_video():
    """Which video add-on fills the rows and plays: Lucent Video works best, Seren and any other add-on work too."""
    if has(LV):
        account = setting(LV, "trakt_user") or setting(LV, "simkl_user")
        return "ok", t(f"Lucent Video is installed{'  ·  account: ' + account if account else ''}",
                       f"Lucent Video staat erop{'  ·  account: ' + account if account else ''}")
    if has(SEREN) and not no_seren():
        return "ok", t("Seren is installed", "Seren staat erop")
    return "info", t("No video add-on for films and series yet", "Nog geen video-add-on voor films en series")


def ac_video():
    out = []
    if has(LV):
        out.append((t("Lucent Video: setup assistant", "Lucent Video: installatie-assistent"),
                    lambda: run("RunPlugin(plugin://plugin.video.lucent/?action=setup)")))
        out.append((t("Lucent Video settings", "Instellingen van Lucent Video"), lambda: run(f"Addon.OpenSettings({LV})")))
    else:
        out.append((t("Install Lucent Video", "Lucent Video installeren"), lambda: install(LV)))
    if has(SEREN):
        if no_seren():
            out.append((t("Use Seren after all", "Toch Seren gebruiken"), seren_on))
        else:
            out.append((t("Seren settings", "Seren-instellingen"), lambda: run(f"Addon.OpenSettings({SEREN})")))
            out.append((t("I don't use Seren", "Ik gebruik geen Seren"), seren_off))
    out.append((t("Menu and widgets", "Menu en widgets"), lambda: run("RunScript(special://skin/scripts/menu.py)")))
    return out


def tmdb_key():
    try:
        import info
        info._KEY["time"] = 0.0                       # always look again
        return info.tmdb_key()
    except Exception as error:  # noqa: BLE001
        log(f"tmdb key: {error}")
        return ""


def st_tmdb():
    if tmdb_key():
        return "ok", t("A TMDb key is set", "Er is een TMDb-sleutel ingesteld")
    return "todo", t("No TMDb key yet", "Nog geen TMDb-sleutel")


def ac_tmdb():
    def enter():
        import info
        info.set_tmdb_key()
    return [(t("Enter key", "Sleutel invoeren"), enter)]


def tv_channels():
    result = rpc("PVR.GetChannels", {"channelgroupid": "alltv", "limits": {"end": 1}}) or {}
    return int((result.get("limits") or {}).get("total") or 0)


def st_iptv():
    if not cond(f"System.HasAddon({IPTV})"):
        if xbmc.getInfoLabel(f"System.AddonVersion({IPTV})"):                # installed, but switched off
            return "todo", t("IPTV Simple Client is switched off", "IPTV Simple Client staat uit")
        return "todo", t("IPTV Simple Client is not installed (no IPTV? Skip this step)",
                         "IPTV Simple Client staat er nog niet op (geen IPTV? Sla over)")
    count = tv_channels()
    if count:
        return "ok", t(f"{count} TV channels", f"{count} tv-zenders")
    return "todo", t("No channels yet: fill in your channel list (M3U) and guide (EPG)",
                     "Nog geen zenders: vul je zenderlijst (M3U) en gids (EPG) in")


def ac_iptv():
    if not cond(f"System.HasAddon({IPTV})"):
        if xbmc.getInfoLabel(f"System.AddonVersion({IPTV})"):
            return [(t("Switch on", "Aanzetten"), lambda: rpc("Addons.SetAddonEnabled", {"addonid": IPTV, "enabled": True}))]
        return [(t("Install IPTV Simple Client", "IPTV Simple Client installeren"), lambda: install(IPTV))]
    out = [(t("Xtream login", "Xtream-inlog"), lambda: run("RunScript(special://skin/scripts/xtream.py)")),
           (t("Channel list and guide", "Zenderlijst en gids"), lambda: run(f"Addon.OpenSettings({IPTV})"))]
    if tv_channels():                       # the window has room for four buttons
        group = xbmc.getInfoLabel("Skin.String(lucent.guide.group)") or t("none", "geen")
        out.append((t(f"Favourite group: {group}", f"Favoriete groep: {group}"),
                    lambda: run("RunScript(special://skin/scripts/guidefav.py,settings)")))
        try:
            import channels
            logos = channels.load().get("logos")
        except Exception:  # noqa: BLE001
            logos = False
        out.append((t("Channel logos: on", "Zenderlogo's: aan") if logos else t("Channel logos: off", "Zenderlogo's: uit"),
                    lambda: run("RunScript(special://skin/scripts/channels.py,logos)")))
    return out


def st_subskip():
    """1.37.0: subtitles, spoken language and skip intro are in Lucent Video now."""
    if not cond(f"System.AddonIsEnabled({LV})"):
        return "info", t("Optional: Lucent Video does subtitles and skip intro", "Optioneel: Lucent Video doet ondertitels en intro overslaan")
    home = xbmcgui.Window(10000)
    parts = [p for p in (home.getProperty("lucent.video.subs.state"), home.getProperty("lucent.video.skip.state")) if p]
    return "ok", "  ·  ".join(parts) or t("In Lucent Video", "In Lucent Video")


def ac_subskip():
    if not cond(f"System.AddonIsEnabled({LV})"):
        return [(t("Install Lucent Video", "Lucent Video installeren"), lambda: install(LV))]
    base = "RunPlugin(plugin://plugin.video.lucent/?action="
    return [(t("Subtitles", "Ondertitels"), lambda: run(base + "subs_setup)")),
            (t("Skip intro", "Intro overslaan"), lambda: run(base + "skip_setup)")),
            (t("Settings", "Instellingen"), lambda: run(base + "subs_settings)"))]




def st_library():
    if not has(LV):
        return "info", t("Optional: Lucent Video can fill Kodi's library", "Optioneel: Lucent Video kan de bibliotheek van Kodi vullen")
    on = setting(LV, "library_on") == "true"
    return ("ok", t("Lucent Video fills the library", "Lucent Video vult de bibliotheek")) if on else \
        ("info", t("Off  ·  switch it on in Lucent Video", "Uit  ·  zet het aan in Lucent Video"))


def ac_library():
    if not has(LV):
        return [(t("Install Lucent Video", "Lucent Video installeren"), lambda: install(LV))]
    base = "RunPlugin(plugin://plugin.video.lucent/?action="
    return [(t("Choose what goes in the library", "Kiezen wat in de bibliotheek komt"), lambda: run(base + "library_choose)")),
            (t("Update now", "Nu bijwerken"), lambda: run(base + "library_sync)")),
            (t("Settings", "Instellingen"), lambda: run("Addon.OpenSettings(plugin.video.lucent)"))]


def st_look():
    lite = cond("Skin.HasSetting(lucent.lite)")
    fy = not cond("Skin.HasSetting(lucent.fy.off)")
    big = not cond("Skin.HasSetting(lucent.posters.small)")
    return "ok", "  ·  ".join([t("Light mode on", "Lichte modus aan") if lite else t("Light mode off", "Lichte modus uit"),
                               t("Tonight for you on", "Vanavond voor jou aan") if fy else t("Tonight for you off", "Vanavond voor jou uit"),
                               t("big posters", "grote posters") if big else t("small posters", "kleine posters")])


def toggle_posters():
    """Big posters (no names) or the old, smaller posters (with names); the skin reloads to get the new row height."""
    if cond("Skin.HasSetting(lucent.posters.small)"):
        run("Skin.SetBool(nuvio.posterlabels.hide)")
    else:
        run("Skin.Reset(nuvio.posterlabels.hide)")
    run("Skin.ToggleSetting(lucent.posters.small)")
    xbmc.sleep(300)
    run("ReloadSkin()")


def ac_look():
    lite = cond("Skin.HasSetting(lucent.lite)")
    return [(t("Light mode: on", "Lichte modus: aan") if lite else t("Light mode: off", "Lichte modus: uit"),
             lambda: (run("Skin.ToggleSetting(lucent.lite)"), xbmc.sleep(400),
                      run("RunScript(special://skin/scripts/settings.py,litebuild)"))),
            (t("Big posters: on", "Grote posters: aan") if not cond("Skin.HasSetting(lucent.posters.small)")
             else t("Big posters: off", "Grote posters: uit"), toggle_posters),
            (t("Menu and rows", "Menu en rijen"), lambda: run("RunScript(special://skin/scripts/menu.py)"))]


def kodi_setting(key):
    return (rpc("Settings.GetSettingValue", {"setting": key}) or {}).get("value")


def set_kodi(key, value):
    rpc("Settings.SetSettingValue", {"setting": key, "value": value})


def ram_mb():
    try:
        return int("".join(ch for ch in xbmc.getInfoLabel("System.Memory(total)") if ch.isdigit()) or 0)
    except ValueError:
        return 0


def buffer_advice():
    """A bigger buffer than Kodi's 64 MB smooths out streams. Kodi can use up to three times this size, so it follows
    the memory of the box: 96 MB up to 2 GB, 192 MB up to 4 GB, 384 MB above that."""
    ram = ram_mb()
    return 96 if 0 < ram <= 2200 else (192 if ram <= 4400 else 384)


PASS = ("audiooutput.ac3passthrough", "audiooutput.eac3passthrough", "audiooutput.dtspassthrough",
        "audiooutput.truehdpassthrough", "audiooutput.dtshdpassthrough")


def st_play():
    size, advice = kodi_setting("filecache.memorysize"), buffer_advice()
    rate = kodi_setting("videoplayer.adjustrefreshrate")
    passthrough = kodi_setting("audiooutput.passthrough")
    parts = [t(f"Buffer {size} MB", f"Buffer {size} MB") + ("" if (size or 0) >= advice else t(f" (advice {advice})", f" (advies {advice})")),
             t("frame rate follows the video", "beeldfrequentie volgt de video") if rate in (1, 2, 3) else t("frame rate fixed", "beeldfrequentie vast"),
             t("sound to amplifier", "geluid naar versterker") if passthrough else t("Kodi decodes the sound", "Kodi zet het geluid om")]
    return ("ok" if (size or 0) >= advice and rate in (1, 2, 3) else "todo"), "  ·  ".join(parts)


def ac_play():
    advice = buffer_advice()
    rate = kodi_setting("videoplayer.adjustrefreshrate")
    passthrough = kodi_setting("audiooutput.passthrough")

    def buffer():
        set_kodi("filecache.memorysize", advice)
        set_kodi("filecache.readfactor", 400)                  # fill the buffer 4x faster than the video plays

    def toggle_rate():
        set_kodi("videoplayer.adjustrefreshrate", 0 if rate in (1, 2, 3) else 2)   # 2: on start and stop

    def toggle_pass():
        on = not passthrough
        set_kodi("audiooutput.passthrough", on)
        if on:
            for key in PASS:
                set_kodi(key, True)
    out = []
    if (kodi_setting("filecache.memorysize") or 0) < advice:
        out.append((t(f"Buffer {advice} MB (advice)", f"Buffer {advice} MB (advies)"), buffer))
    out.append((t("Frame rate: follows video", "Beeldfrequentie: volgt video") if rate in (1, 2, 3) else t("Frame rate: fixed", "Beeldfrequentie: vast"), toggle_rate))
    out.append((t("Sound to amplifier: on", "Geluid naar versterker: aan") if passthrough else t("Sound to amplifier: off", "Geluid naar versterker: uit"), toggle_pass))
    out.append((t("Player settings", "Spelerinstellingen"), lambda: run("ActivateWindow(PlayerSettings)")))
    return out


def st_backup():
    import backup
    last = backup.last_backup()
    if last:
        return "ok", t(f"Last backup: {last}", f"Laatste back-up: {last}")
    return "todo", t("No backup yet", "Nog geen back-up")


def ac_backup():
    return [(t("Make a backup", "Back-up maken"), lambda: run("RunScript(special://skin/scripts/backup.py,backup)")),
            (t("Restore", "Herstellen"), lambda: run("RunScript(special://skin/scripts/backup.py,restore)"))]



# ----------------------------------------------------------------------------- tabs (only with the Solis add-on)
SOLIS = "script.solis.dashboard"
SOLIS_ACTION = f"RunAddon({SOLIS})"


def solis_tab():
    import menu
    return any(SOLIS in tab["action"] for tab in menu.Menu().tabs)


def st_tabs():
    if solis_tab():
        return "ok", t("Solis Dashboard has its own tab on Home", "Solis Dashboard heeft een eigen tabblad op Home")
    return "todo", t("Solis Dashboard is installed but has no tab on Home yet", "Solis Dashboard staat erop, maar heeft nog geen tabblad op Home")


def add_solis_tab():
    import menu
    m = menu.Menu()
    if solis_tab():
        return
    if len(m.tabs) >= menu.NTABS:
        xbmcgui.Dialog().ok("Lucent", t("The side menu is full. Remove a tab in Menu and widgets first.",
                                        "Het zijmenu is vol. Haal eerst een tabblad weg bij Menu en widgets."))
        return
    at = next((i for i, tab in enumerate(m.tabs) if tab["action"] in ("AddonBrowser", "ActivateWindow(Settings)")
               or "AddonBrowser" in tab["action"]), len(m.tabs))
    start = m.start_tab()
    m.tabs.insert(at, {"label": "Solis Dashboard", "icon": "icons/sparkle.png", "action": SOLIS_ACTION, "widgets": [], "actionlabel": ""})
    m.start = start
    m.save()
    xbmcgui.Dialog().notification("Lucent", t("Solis Dashboard tab added", "Tabblad Solis Dashboard toegevoegd"), "", 3000, False)


def ac_tabs():
    if solis_tab():
        return [(t("Menu and widgets", "Menu en widgets"), lambda: run("RunScript(special://skin/scripts/menu.py)"))]
    return [(t("Add a Solis Dashboard tab", "Tabblad Solis Dashboard toevoegen"), add_solis_tab),
            (t("Menu and widgets", "Menu en widgets"), lambda: run("RunScript(special://skin/scripts/menu.py)"))]

STEPS = [
    ("welcome", "icons/sparkle.png", ("Welcome", "Welkom"),
     ("Welcome to Lucent. In a few steps we set up what matters most: the video add-on for films and series, a TMDb key "
      "for pictures and information, your IPTV channels, subtitles and your own library.\n\nEvery step shows how it stands "
      "right now. Something you do not use, you simply skip. You can open this assistant again later: "
      "Settings > Lucent > Setup assistant.",
      "Welkom bij Lucent. In een paar stappen zetten we het belangrijkste klaar: de video-add-on voor films en series, een "
      "TMDb-sleutel voor plaatjes en informatie, je IPTV-zenders, ondertitels en je eigen bibliotheek.\n\nBij elke stap "
      "zie je meteen hoe het nu staat. Wat je niet gebruikt, sla je gewoon over. Je kunt deze assistent later opnieuw "
      "openen: Instellingen > Lucent > Setup-assistent."), st_welcome, ac_welcome),
    ("video", "icons/play.png", ("Films and series", "Films en series"),
     ("Lucent works with every video add-on: long-press OK on a folder in any add-on and choose 'Add to Home as widget'. "
      "With Lucent Video it works best: its rows fill Home by themselves, and the buttons on the info page (play, "
      "watched, lists, trailer, more) use it - also for titles from other add-ons.\n\nUse Seren? That works too; "
      "Lucent then also offers Seren's rows.",
      "Lucent werkt met elke video-add-on: houd OK ingedrukt op een map in een add-on en kies 'Toevoegen aan Home als "
      "widget'. Met Lucent Video werkt het het best: de rijen op Home vullen zich vanzelf, en de knoppen op de "
      "infopagina (afspelen, bekeken, lijsten, trailer, meer) gebruiken het - ook voor titels uit andere add-ons.\n\n"
      "Gebruik je Seren? Dat kan ook; Lucent biedt dan ook de rijen van Seren aan."), st_video, ac_video),
    ("tmdb", "icons/movies.png", ("TMDb key", "TMDb-sleutel"),
     ("TMDb (The Movie Database) supplies posters, logos, cast, studios and trailers. A key of your own is free and "
      "makes everything faster and more complete.\n\nGet one: make an account on themoviedb.org, then Settings > API > "
      "'Create' (personal use). Copy the 'API key' (the short one, 32 characters).",
      "TMDb (The Movie Database) levert posters, logo's, acteurs, studio's en trailers. Een eigen sleutel is gratis en "
      "maakt alles sneller en vollediger.\n\nZo krijg je er een: maak een account op themoviedb.org, dan Instellingen > "
      "API > 'Aanmaken' (persoonlijk gebruik). Kopieer de 'API-sleutel' (de korte, 32 tekens)."), st_tmdb, ac_tmdb),
    ("iptv", "icons/tv.png", ("Live TV (IPTV)", "Live tv (IPTV)"),
     ("For live TV Kodi uses IPTV Simple Client. Have an Xtream login (server address, user name, password)? "
      "Press 'Xtream login': Lucent checks it with the server and sets up IPTV Simple for you - channels, guide and replay. "
      "Got an M3U and EPG link instead? Fill those in under 'Channel list and guide'.\n\nAfter that Lucent shows the TV "
      "guide, the Sport tab and live scores on the channels. 'Favourite group' opens first in the guide and fills the TV tab "
      "on Home; 'Channel logos' puts clean logos (tv-logos) in place of your provider's.",
      "Voor live tv gebruikt Kodi IPTV Simple Client. Heb je een Xtream-login (serveradres, gebruikersnaam, wachtwoord)? "
      "Druk op 'Xtream-inlog': Lucent controleert hem bij de server en stelt IPTV Simple voor je in - zenders, gids en "
      "terugkijken. Heb je een M3U- en EPG-link? Vul die in bij 'Zenderlijst en gids'.\n\nDaarna toont Lucent de tv-gids, "
      "de Sport-tab en live standen bij de zenders. 'Favoriete groep' opent als eerste in de gids en vult het tv-tabblad "
      "op Home; 'Zenderlogo's' zet nette logo's (tv-logos) in plaats van die van je aanbieder."),
     st_iptv, ac_iptv),
    ("play", "icons/videosettings.png", ("Picture and sound", "Beeld en geluid"),
     ("Three things that make watching smoother. A bigger buffer: Kodi loads more of the stream ahead, so it stutters less "
      "(Lucent picks a size that suits the memory of this box). Frame rate that follows the video: films are made at 24 frames "
      "a second; when the TV switches to 23.976/24 Hz, panning shots run without jerks. Sound to the amplifier (passthrough): "
      "Dolby, DTS and Atmos go untouched to your soundbar or receiver - only switch it on when you have one.\n\nHDR and Dolby Vision "
      "are passed on by themselves on CoreELEC.",
      "Drie dingen die het kijken soepeler maken. Een grotere buffer: Kodi laadt meer van de stream vooruit, zodat het minder "
      "hapert (Lucent kiest een grootte die past bij het geheugen van deze box). Beeldfrequentie die de video volgt: films zijn "
      "gemaakt met 24 beelden per seconde; schakelt de tv naar 23,976/24 Hz, dan lopen pannende beelden zonder schokjes. Geluid naar "
      "de versterker (passthrough): Dolby, DTS en Atmos gaan onbewerkt naar je soundbar of receiver - zet dit alleen aan als je die hebt."
      "\n\nHDR en Dolby Vision geeft CoreELEC vanzelf door."), st_play, ac_play),
    ("subs", "icons/subtitles.png", ("Subtitles and skip intro", "Ondertitels en intro overslaan"),
     ("Optional. Lucent Video finds subtitles in your language (it asks every subtitle add-on at the same time), chooses the "
      "spoken language, translates English subtitles with AI when you want, and skips intros with TheIntroDB. "
      "It works for every video, also from other add-ons.",
      "Optioneel. Lucent Video zoekt ondertitels in jouw taal (het vraagt alle ondertitel-add-ons tegelijk), kiest de "
      "gesproken taal, vertaalt Engelse ondertitels met AI als je dat wilt, en slaat intro's over met TheIntroDB. "
      "Het werkt voor elke video, ook uit andere add-ons."), st_subskip, ac_subskip),
    ("library", "icons/library.png", ("Library", "Bibliotheek"),
     ("Optional. Lucent Video turns your Trakt (or Simkl) collection and lists into Kodi's own library: films and series "
      "with their own pages, 'Continue watching' and 'Next episode' rows, and watched marks that stay in step.",
      "Optioneel. Lucent Video maakt van je Trakt- (of Simkl-)collectie en lijsten de eigen bibliotheek van Kodi: films en "
      "series met eigen pagina's, rijen 'Verder kijken' en 'Volgende aflevering', en bekeken-vinkjes die gelijk blijven."),
     st_library, ac_library),
    ("tabs", "icons/layout.png", ("Tabs", "Tabbladen"),
     ("Solis Dashboard (for solar panels with Solis voor Homey) can get its own tab on Home: it shows the numbers of now - "
      "solar panels, house, grid, today and this month - and OK opens the dashboard.\n\nOther tabs you add, move or remove "
      "in Menu and widgets.",
      "Solis Dashboard (voor zonnepanelen met Solis voor Homey) kan een eigen tabblad op Home krijgen: dat laat de cijfers "
      "van nu zien - zonnepanelen, huis, net, vandaag en deze maand - en OK opent het dashboard.\n\nAndere tabbladen voeg "
      "je toe, verplaats je of haal je weg bij Menu en widgets."), st_tabs, ac_tabs),
    ("look", "icons/palette.png", ("Look", "Weergave"),
     ("Light mode keeps Lucent quick on boxes with 2 GB of memory or less (fewer rows, no poster glow) - Lucent switches "
      "it on by itself on such boxes. 'Tonight for you' is a row on Home with titles that fit the moment of the day.\n\n"
      "Big posters fill the space under the information; switch them off for the smaller posters with names.\n\n"
      "Colours, the menu and the rows on Home can be changed any time in Skin settings.",
      "Lichte modus houdt Lucent vlot op boxen met 2 GB geheugen of minder (minder rijen, geen postergloed) - op zulke "
      "boxen zet Lucent hem zelf aan. 'Vanavond voor jou' is een rij op het startscherm met titels die passen bij het "
      "moment van de dag. Grote posters vullen de ruimte onder de informatie; zet ze uit voor de kleinere posters met namen.\n\n"
      "Kleuren, het menu en de rijen op het startscherm pas je altijd aan in Skin-instellingen."), st_look, ac_look),
    ("backup", "icons/cloud.png", ("Backup", "Back-up"),
     ("Save everything you set up in one file: Lucent's settings and menu, your favourites, the keys (TMDb, AI), the "
      "settings of your video add-ons and IPTV Simple, and your sources. Put it on a USB stick or a network share, and "
      "after a new installation (or on a second box) 'Restore' puts it all back.\n\nThe file holds your logins (Trakt, IPTV): "
      "keep it to yourself.",
      "Bewaar alles wat je hebt ingesteld in één bestand: de instellingen en het menu van Lucent, je favorieten, de sleutels "
      "(TMDb, AI), de instellingen van je video-add-ons en IPTV Simple, en je bronnen. Zet het op een USB-stick of "
      "netwerkmap; na een nieuwe installatie (of op een tweede box) zet 'Herstellen' alles terug.\n\nIn het bestand staan je "
      "inlogs (Trakt, IPTV): houd het voor jezelf."), st_backup, ac_backup),
]


if not cond(f"System.AddonIsEnabled({SOLIS})"):          # the Tabs step is only for the Solis add-on for now
    STEPS = [step for step in STEPS if step[0] != "tabs"]


class Setup(xbmcgui.WindowXMLDialog):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.step = 0
        self.actions = []
        self.closing = False
        self.lock = threading.Lock()

    def onInit(self):
        self.setProperty("heading", t("Set up Lucent", "Lucent instellen"))
        self.items = []
        for key, icon, title, _body, _st, _ac in STEPS:
            li = xbmcgui.ListItem(title[1 if NL else 0])
            li.setArt({"icon": icon})
            self.items.append(li)
        self.getControl(100).addItems(self.items)
        self.show_step(0)
        threading.Thread(target=self.watch, daemon=True).start()

    # ----------------------------------------------------------------- drawing
    def show_step(self, index):
        self.step = max(0, min(index, len(STEPS) - 1))
        key, _icon, title, body, _st, _ac = STEPS[self.step]
        self.setProperty("stepno", t(f"Step {self.step + 1} of {len(STEPS)}", f"Stap {self.step + 1} van {len(STEPS)}"))
        self.setProperty("title", title[1 if NL else 0])
        self.setProperty("body", body[1 if NL else 0])
        self.setProperty("prev", t("Back", "Vorige") if self.step else "")
        last = self.step == len(STEPS) - 1
        self.setProperty("next", t("Finish", "Klaar") if last else (t("Start", "Beginnen") if self.step == 0 else t("Next", "Volgende")))
        self.setProperty("later", "" if last else t("Set up later", "Later instellen"))
        for n, li in enumerate(self.items):
            li.setProperty("current", "1" if n == self.step else "")
        self.getControl(100).selectItem(self.step)
        self.refresh()
        self.setFocusId(300 if self.actions else 402)

    def refresh(self):
        """Status of every step (ticks in the list) and the buttons of this step."""
        with self.lock:
            for n, (_k, _i, _t, _b, status, _a) in enumerate(STEPS):
                try:
                    state, text = status()
                except Exception as error:  # noqa: BLE001
                    log(f"status {STEPS[n][0]}: {error}")
                    state, text = "info", ""
                self.items[n].setProperty("state", state)
                if n == self.step:
                    self.setProperty("status", text)
                    self.setProperty("statecolor", {"ok": GREEN, "todo": ORANGE}.get(state, GREY))
            try:
                self.actions = STEPS[self.step][5]()[:4]
            except Exception as error:  # noqa: BLE001
                log(f"actions: {error}")
                self.actions = []
            for n in range(4):
                self.setProperty(f"act{n + 1}", self.actions[n][0] if n < len(self.actions) else "")

    def watch(self):
        """Look again every two seconds: linking Trakt or installing an add-on happens in other windows."""
        monitor = xbmc.Monitor()
        while not self.closing and not monitor.abortRequested():
            if monitor.waitForAbort(2):
                break
            if not self.closing:
                self.refresh()

    # ----------------------------------------------------------------- input
    def onClick(self, control_id):
        if control_id == 100:
            self.show_step(self.getControl(100).getSelectedPosition())
        elif 301 <= control_id <= 304:
            n = control_id - 301
            if n < len(self.actions):
                try:
                    self.actions[n][1]()
                except Exception as error:  # noqa: BLE001
                    log(f"action: {error}")
                xbmc.sleep(300)
                self.refresh()
        elif control_id == 401:
            self.show_step(self.step - 1)
        elif control_id == 402:
            if self.step == len(STEPS) - 1:
                self.finish()
            else:
                self.show_step(self.step + 1)
        elif control_id == 403:
            self.finish(later=True)

    def onAction(self, action):
        if action.getId() in (10, 92):                       # back / previous menu
            self.finish(later=True)

    def finish(self, later=False):
        self.closing = True
        xbmc.executebuiltin(f'Skin.SetString({DONE},"1")')
        if later:
            xbmcgui.Dialog().notification("Lucent", t("Setup assistant: Settings > Lucent", "Setup-assistent: Instellingen > Lucent"),
                                          "special://skin/resources/icon.png", 4000, False)
        self.close()


def open_window():
    path = xbmcaddon.Addon("skin.lucent").getAddonInfo("path")
    window = Setup("Lucent_Setup.xml", path, "Default", "1080i")
    try:
        window.doModal()
    finally:
        window.closing = True
        del window


if __name__ == "__main__":
    first = len(sys.argv) > 1 and sys.argv[1] == "first"
    if first:
        home = xbmcgui.Window(10000)
        if xbmc.getInfoLabel(f"Skin.String({DONE})") or home.getProperty("lucent.setup.shown"):
            sys.exit()
        home.setProperty("lucent.setup.shown", "1")          # once per Kodi start, even when closed with Back
        if xbmc.Monitor().waitForAbort(2):                    # let Home settle first
            sys.exit()
    open_window()

# -*- coding: utf-8 -*-
"""Lucent: everything that has to happen once when Kodi starts, in ONE Python start.

    RunScript(special://skin/scripts/startup.py)      from Home.xml, only the first time Home opens

Before this, Home started five or six separate scripts at the same time (key maps, rating logos, the Calendar and
Sport tabs, the helper). Every one of them is its own Python interpreter, and on a small box they all compete with
the video add-on and the widgets that load at that moment. Now the quick jobs run here after each other, and the long-running
helper is started last, in this same interpreter.
"""
import xbmc


def log(text):
    xbmc.log(f"[skin.lucent] startup: {text}", xbmc.LOGINFO)


def step(name, func):
    try:
        func()
    except Exception as error:  # noqa: BLE001 - one job must never stop the others
        log(f"{name}: {error}")


def season_page():
    """Kodi skips the seasons of a series with only one season ('Flatten TV show seasons: if only one season'), so
    such a series opened as a bare episode list instead of Lucent's series page with the season tabs. Set it once
    to 'Never' (you can change it back in Kodi's settings; Lucent does not ask again)."""
    if xbmc.getCondVisibility("Skin.HasSetting(lucent.seasontabs.off) | !String.IsEmpty(Skin.String(lucent.flattenset))"):
        return
    import json
    req = {"jsonrpc": "2.0", "id": 1, "method": "Settings.GetSettingValue", "params": {"setting": "videolibrary.flattentvshows"}}
    value = (json.loads(xbmc.executeJSONRPC(json.dumps(req))).get("result") or {}).get("value")
    if value not in (None, 0):
        req = {"jsonrpc": "2.0", "id": 1, "method": "Settings.SetSettingValue",
               "params": {"setting": "videolibrary.flattentvshows", "value": 0}}
        log(f"flatten seasons {value} -> 0: {xbmc.executeJSONRPC(json.dumps(req))}")
    xbmc.executebuiltin("Skin.SetString(lucent.flattenset,1)")


LUCENT_ADDONS = ("skin.lucent", "plugin.video.lucent", "service.subtitles.lucent", "repository.lucent", "screensaver.lucent")


def fresh_icons():
    """Kodi keeps a copy of every add-on icon and only looks at the file again after a day, so a new icon showed in
    the info window but not in the lists. After an update of a Lucent add-on, its old copies are thrown away."""
    import json

    def rpc(method, params):
        return json.loads(xbmc.executeJSONRPC(json.dumps({"jsonrpc": "2.0", "id": 1, "method": method, "params": params})))
    for addon in LUCENT_ADDONS:
        version = xbmc.getInfoLabel(f"System.AddonVersion({addon})")
        key = f"lucent.iconver.{addon}"
        if not version or xbmc.getInfoLabel(f"Skin.String({key})") == version:
            continue
        found = (rpc("Textures.GetTextures", {"properties": ["url"], "filter": {"field": "url", "operator": "contains",
                                                                                "value": f"/addons/{addon}/"}})
                 .get("result") or {}).get("textures") or []
        gone = 0
        for tex in found:
            if any(tex.get("url", "").lower().endswith(name) for name in ("icon.png", "fanart.jpg", "fanart.png")):
                rpc("Textures.RemoveTexture", {"textureid": tex["textureid"]})
                gone += 1
        log(f"{addon} {version}: {gone} old icon copies removed")
        xbmc.executebuiltin(f"Skin.SetString({key},{version})")


def _skin(key):
    return xbmc.getInfoLabel(f"Skin.String({key})")


def first_start():
    """A new installation: the one-time jobs one after the other (they used to start as six scripts at the same time
    from Home, which made small boxes hang). Returns True when the skin reloads for the light mode."""
    import settings
    if not _skin("lucent.lite.checked"):
        step("light mode check", settings.lite_check)
    if not _skin("nuvio.migrated"):
        import migrate
        step("settings of Nuvio Arc", migrate.migrate)
        xbmc.executebuiltin('Skin.SetString(nuvio.migrated,"1")', True)
        if _skin("nuvio.menu.version"):
            step("settings", settings.sync)
    if not _skin("nuvio.menu.version"):
        import menu
        step("menu", menu.init)
    elif not _skin("lucent.addonw4"):
        import menu
        step("add-ons row", menu.addons_once)
    if xbmc.getCondVisibility("System.HasAddon(plugin.video.lucent)") and _skin("lucent.lvrows") != "done4" \
            and _skin("nuvio.menu.version"):
        import menu
        step("rows of the video add-on", menu.lv_convert)
    if not _skin("lucent.searchtab") and _skin("nuvio.menu.version"):
        import menu
        step("search tab", menu.search_convert)
    lite = xbmc.getCondVisibility("Skin.HasSetting(lucent.lite)")
    if lite != bool(_skin("lucent.lite.built")):
        step("light mode", settings.lite_build)      # reloads the skin: Home starts this script again
        return True
    return False


def cw_notice():
    """2.1.4: the Continue watching row from the library is no longer put on the Films and Series tabs by itself. Tell
    people who used Lucent before, once, how to add it themselves as a widget. A new installation gets no message."""
    import threading

    def show():
        import xbmcgui
        mon = xbmc.Monitor()
        mon.waitForAbort(6)                                 # let Home appear first
        for _ in range(600):                                # then wait until Home is on top, without a dialog
            if xbmc.getCondVisibility("Window.IsActive(home) + !System.HasModalDialog + !System.HasVisibleModalDialog") \
                    or mon.waitForAbort(1):
                break
        if mon.abortRequested():
            return
        nl = xbmc.getLanguage(xbmc.ISO_639_1) == "nl"
        if nl:
            head, text = "Lucent: Verder kijken", (
                "De rij [B]Verder kijken[/B] uit je bibliotheek staat niet meer vanzelf op de tabbladen Films en Series.[CR][CR]"
                "Wil je hem terug? Zet hem als widget: Menu en widgets > kies het tabblad > Widgets op deze tab > "
                "Kodi-bibliotheek > [B]Films die je kijkt[/B], [B]Series die je kijkt[/B] of [B]Afleveringen die je kijkt[/B].")
        else:
            head, text = "Lucent: Continue watching", (
                "The [B]Continue watching[/B] row from your library is no longer put on the Films and Series tabs by itself.[CR][CR]"
                "Want it back? Add it as a widget: Menu and widgets > choose the tab > Widgets on this tab > "
                "Kodi library > [B]Movies in progress[/B], [B]Shows in progress[/B] or [B]Episodes in progress[/B].")
        xbmcgui.Dialog().ok(head, text)

    if _skin("lucent.notice.cw214"):
        return
    xbmc.executebuiltin('Skin.SetString(lucent.notice.cw214,"1")')
    if _skin("lucent.setup.done"):                          # used Lucent before this version
        threading.Thread(target=show, daemon=True).start()


def touch_screen():
    """2.1.39 (#30): is this a touch screen (phone or tablet)? Kodi has no condition for it, so Lucent looks once per
    start. iPhone/iPad: yes. Android (2.1.40, the first look only knew /system and missed phones that keep the list in
    /vendor, like Samsung): the device type Android gives (ro.build.characteristics: phone, tablet or tv), then the
    feature lists of every partition (handheld/tablet = touch, TV/leanback = not). Skin.HasSetting(lucent.touch) then
    shows the Options button in the lists."""
    import os
    import subprocess
    cond = xbmc.getCondVisibility
    touch, why = False, "not Android or iOS"
    if cond("System.Platform.IOS"):
        touch, why = True, "iOS"
    elif cond("System.Platform.Android"):
        kind = ""
        for exe in ("/system/bin/getprop", "getprop"):
            try:
                kind = subprocess.run([exe, "ro.build.characteristics"], capture_output=True, text=True, timeout=3).stdout.strip().lower()
                break
            except Exception:  # noqa: BLE001
                continue
        files = set()
        for part in ("/system", "/vendor", "/product", "/odm", "/system_ext"):
            try:
                files.update(os.listdir(part + "/etc/permissions"))
            except OSError:
                pass
        tv = "tv" in kind.split(",") or bool(files & {"tv_core_hardware.xml", "android.software.leanback.xml", "android.software.leanback_only.xml"})
        hand = bool({"phone", "tablet"} & set(kind.split(","))) or bool(files & {"handheld_core_hardware.xml", "tablet_core_hardware.xml"})
        touch = hand and not tv
        why = f"Android type '{kind or '-'}', handheld={hand}, tv={tv}, {len(files)} feature files"
    if touch != bool(cond("Skin.HasSetting(lucent.touch)")):
        xbmc.executebuiltin("Skin.SetBool(lucent.touch)" if touch else "Skin.Reset(lucent.touch)")
    log(f"touch screen: {touch} ({why})")


def saver_keymap():
    """3.0.8: Lucent Screensaver 1.2.2 makes OK 'Mute' while it runs (to know OK woke it). Should Kodi have stopped
    during the screensaver, that small keymap is still there: remove it, or OK would keep muting."""
    import xbmcvfs
    path = "special://profile/keymaps/lucent_saver_ok.xml"
    if xbmcvfs.exists(path) and not xbmc.getCondVisibility("System.ScreenSaverActive"):
        xbmcvfs.delete(path)
        xbmc.executebuiltin("Action(reloadkeymaps)")
        log("removed the screensaver's OK keymap")


def run():
    # 2.1.49: the context menu (DialogContextMenu.xml) shows the video add-on's library options itself, at the top;
    # this tells the add-on to hide its own copies, which Kodi would put at the bottom
    xbmc.executebuiltin("SetProperty(lucent.skin.libctx,1,home)")
    xbmc.executebuiltin("SetProperty(lucent.skin.libctx.all,1,home)")   # 2.1.50: all its other library options too
    step("touch screen", touch_screen)
    step("screensaver keymap", saver_keymap)
    if first_start():
        return
    step("season page", season_page)
    step("fresh icons", fresh_icons)
    import keymap
    step("keymap", keymap.main)
    import settings
    step("logos", settings.scan_logos)
    import agenda
    step("calendar tab", agenda.ensure_tab)
    if xbmc.getCondVisibility("Pvr.HasTVChannels"):
        import sport
        step("sport tab", sport.ensure_tab)
    if not _skin("lucent.setup.done") and not xbmc.getInfoLabel("Window(home).Property(lucent.setup.shown)"):
        xbmc.executebuiltin("RunScript(special://skin/scripts/setup.py,first)")   # the very first time, after the jobs above
    step("continue watching notice", cw_notice)
    import helper
    helper.run()                                     # keeps running until Kodi stops or the skin is updated


if __name__ == "__main__":
    run()

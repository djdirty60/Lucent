# -*- coding: utf-8 -*-
"""Lucent's own widget rows, straight from TMDb (no other add-on involved).

    plugin://script.lucent.library/?action=tmdb&list=trending_movie

The row is answered at once from a saved copy (the plugin part only reads). The Lucent Library service keeps the copies
fresh: one request to TMDb per list, every 6 hours, never while a video plays; a failed request keeps the old copy
and is tried again later. A click on a title opens its own page in Lucent (Play there goes to Seren), the same way as the
"Tonight for you" row. Needs the TMDb key Lucent already uses (Seren's setting, or the key in Skin settings).
"""
import json
import os
import time
import urllib.parse
import urllib.request

import xbmc
import xbmcaddon
import xbmcgui
import xbmcvfs

ADDON_ID = "script.lucent.library"
DIR = xbmcvfs.translatePath(f"special://profile/addon_data/{ADDON_ID}/tmdb/")
REG = os.path.join(DIR, "registry.json")
HOME = xbmcgui.Window(10000)
TTL = 6 * 3600
BACKOFF = (120, 600, 1800)
TMDB = "https://api.themoviedb.org/3/"
IMG = "https://image.tmdb.org/t/p/"
NL = xbmc.getLanguage(xbmc.ISO_639_1) == "nl"

# list name -> (TMDb endpoint, kind, label en, label nl)
LISTS = {
    "trending_movie": ("trending/movie/week", "movie", "Trending movies", "Trending films"),
    "trending_tv": ("trending/tv/week", "tvshow", "Trending shows", "Trending series"),
    "popular_movie": ("movie/popular", "movie", "Popular movies", "Populaire films"),
    "popular_tv": ("tv/popular", "tvshow", "Popular shows", "Populaire series"),
    "toprated_movie": ("movie/top_rated", "movie", "Top rated movies", "Best beoordeelde films"),
    "toprated_tv": ("tv/top_rated", "tvshow", "Top rated shows", "Best beoordeelde series"),
    "nowplaying_movie": ("movie/now_playing", "movie", "In cinemas now", "Nu in de bioscoop"),
    "upcoming_movie": ("movie/upcoming", "movie", "Coming soon (movies)", "Binnenkort (films)"),
    "airing_tv": ("tv/on_the_air", "tvshow", "Series on air", "Series die nu lopen"),
}
SERIES_SORTED = ("trending", "popular", "toprated", "nowplaying", "upcoming", "airing")


def log(text):
    xbmc.log(f"[script.lucent.library] tmdb: {text}", xbmc.LOGINFO)


def read_json(path, default=None):
    try:
        with open(path, encoding="utf-8") as fh:
            return json.load(fh)
    except Exception:  # noqa: BLE001
        return default


def write_json(path, data):
    try:
        os.makedirs(os.path.dirname(path), exist_ok=True)
        tmp = f"{path}.{os.getpid()}.tmp"
        with open(tmp, "w", encoding="utf-8") as fh:
            json.dump(data, fh)
        os.replace(tmp, path)
    except Exception as error:  # noqa: BLE001
        log(f"write {os.path.basename(path)}: {error}")


def cache_file(name):
    return os.path.join(DIR, f"{name}.json")


def tmdb_key():
    try:
        key = (xbmcaddon.Addon("plugin.video.seren").getSetting("tmdb.apikey") or "").strip()
    except Exception:  # noqa: BLE001 - Seren not installed
        key = ""
    for path in ("special://profile/addon_data/skin.lucent/tmdb_key.txt", "special://profile/addon_data/script.lucent.library/tmdb_key.txt"):
        if key:
            break
        try:
            with xbmcvfs.File(path) as fh:
                key = (fh.read() or "").strip()
        except Exception:  # noqa: BLE001
            key = ""
    return key


# ----------------------------------------------------------------------------- TMDb -> row entries
def entry_of(result, kind):
    tmdb_id = result.get("id")
    title = result.get("title") or result.get("name") or ""
    date = result.get("release_date") or result.get("first_air_date") or ""
    year = int(date[:4]) if date[:4].isdigit() else 0
    poster = f"{IMG}w500{result['poster_path']}" if result.get("poster_path") else ""
    fanart = f"{IMG}w1280{result['backdrop_path']}" if result.get("backdrop_path") else ""
    query = urllib.parse.urlencode({"action": "tmdbopen", "type": "movie" if kind == "movie" else "tv", "tmdb": tmdb_id, "year": year or ""})
    return {"type": kind, "label": title, "title": title, "plot": result.get("overview") or "", "year": year,
            "rating": float(result.get("vote_average") or 0), "premiered": date,
            "art": {"poster": poster, "thumb": poster, "fanart": fanart},
            "file": f"plugin://{ADDON_ID}/?{query}", "filetype": "file", "action": True,
            "props": {"tmdb_id": str(tmdb_id or "")}}


def fetch(name):
    """The entries of one list, or None when TMDb does not answer."""
    endpoint, kind = LISTS[name][0], LISTS[name][1]
    key = tmdb_key()
    if not key:
        return None
    params = {"api_key": key, "language": "nl-NL" if NL else "en-US", "page": 1}
    if name in ("nowplaying_movie", "upcoming_movie"):
        params["region"] = "NL" if NL else "US"
    url = f"{TMDB}{endpoint}?{urllib.parse.urlencode(params)}"
    try:
        req = urllib.request.Request(url, headers={"User-Agent": "Lucent/1.0", "Accept": "application/json"})
        with urllib.request.urlopen(req, timeout=20) as resp:
            data = json.loads(resp.read().decode("utf-8"))
    except Exception as error:  # noqa: BLE001
        log(f"{name}: {type(error).__name__}")
        return None
    rows = [entry_of(r, kind) for r in (data.get("results") or []) if r.get("poster_path")]
    return rows[:20] or None


# ----------------------------------------------------------------------------- the plugin part (reads only)
def list_name(path):
    q = urllib.parse.parse_qs(urllib.parse.urlsplit(path).query)
    return (q.get("list") or [""])[0]


def register(name, row):
    reg = read_json(REG, {}) or {}
    item = reg.setdefault(name, {"rows": []})
    if (not row or row in item["rows"]) and time.time() - item.get("seen", 0) < 600 and name in reg and item.get("seen"):
        return                                              # known and seen lately: nothing to write
    if row and row not in item["rows"]:
        item["rows"] = (item["rows"] + [row])[-4:]
    item["seen"] = time.time()
    write_json(REG, reg)


def show(handle, path, row):
    """Answer a row at once from its saved copy; an unknown list name gives an empty row."""
    import widget
    name = list_name(path)
    if name not in LISTS:
        widget.answer(handle, [])
        return
    register(name, row)
    saved = read_json(cache_file(name), {}) or {}
    widget.answer(handle, saved.get("items") or [])


def open_title(query):
    """A click on a title: its own page in Lucent (Play there goes to Seren)."""
    q = urllib.parse.parse_qs(query.lstrip("?"))
    get = lambda k: (q.get(k) or [""])[0]  # noqa: E731
    HOME.setProperty("nuvio.open.tmdb", get("tmdb"))
    HOME.setProperty("nuvio.open.type", get("type") or "movie")
    HOME.setProperty("nuvio.open.year", get("year"))
    HOME.setProperty("nuvio.open.path", "")
    HOME.clearProperty("nuvio.open.trakt")
    xbmc.executebuiltin("RunScript(special://skin/scripts/info.py,open,path)")


# ----------------------------------------------------------------------------- the fetching (runs in the service)
def tick(player_busy=False):
    """One step: fetch one list that is missing or old. True when a request was made."""
    if player_busy or not os.path.exists(REG):
        return False
    reg = read_json(REG, {}) or {}
    now = time.time()
    for name in sorted(reg, key=lambda n: os.path.getmtime(cache_file(n)) if os.path.exists(cache_file(n)) else 0):
        if name not in LISTS:
            continue
        item = reg[name]
        saved = read_json(cache_file(name), {}) or {}
        if saved.get("items") and now - saved.get("time", 0) < TTL:
            continue
        if now < item.get("retry", 0):
            continue
        items = fetch(name)
        if items:
            changed = items != saved.get("items")
            write_json(cache_file(name), {"time": now, "items": items})
            item.update(fail=0, retry=0)
            if changed:
                for row in item.get("rows") or []:
                    HOME.setProperty(f"lucent.wr.{row}", str(now))
            log(f"{name}: {len(items)} titles")
        else:
            fail = int(item.get("fail", 0))
            item.update(fail=fail + 1, retry=now + BACKOFF[min(fail, len(BACKOFF) - 1)])
        write_json(REG, reg)
        return True
    return False

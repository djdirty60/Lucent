# -*- coding: utf-8 -*-
"""Lucent widget cache.

The Lucent skin asks for its Home rows through this add-on:
    plugin://script.lucent.library/?action=widget&row=3&path=<the real path, e.g. a Seren list>

  - With a saved copy of that row it answers at once with the saved items. When the copy is older than a few
    minutes it starts a refresh in the background (RunScript ... widget_refresh); when that is done it sets
    Window(home).Property(lucent.wr.<row>) and the skin reloads the row - now with the fresh copy.
  - Without a saved copy it asks the real path (Kodi's JSON-RPC Files.GetDirectory), saves and shows it.
    An empty answer is tried once more after a few seconds.
  - A refresh that comes back empty (Seren / internet hiccup) never replaces a good copy.

Seren's own properties (trakt_id, trakt_show_id, ...) are not given by JSON-RPC, so they are read back from the
action_args in the Seren path of every item.
"""
import hashlib
import json
import os
import sys
import threading
import time
import urllib.parse

import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin
import xbmcvfs

ADDON_ID = "script.lucent.library"
DIR = xbmcvfs.translatePath(f"special://profile/addon_data/{ADDON_ID}/widgets/")
HOME = xbmcgui.Window(10000)
TTL = 10 * 60               # a saved row older than this is refreshed in the background
STALE_FLAG = os.path.join(DIR, "stale")   # written after playback: every row is refreshed on its next showing
PROPS = ["title", "art", "plot", "plotoutline", "year", "genre", "rating", "votes", "playcount", "resume",
         "runtime", "season", "episode", "showtitle", "firstaired", "premiered", "mpaa", "uniqueid", "tagline",
         "studio", "country", "director", "writer", "originaltitle", "trailer", "dateadded", "lastplayed"]
BASIC = ["title", "art", "plot", "year", "genre", "rating", "playcount", "resume", "runtime", "season", "episode",
         "showtitle", "premiered", "uniqueid"]


def log(text):
    xbmc.log(f"[{ADDON_ID}] widgets: {text}", xbmc.LOGINFO)


def key_of(path):
    return hashlib.md5(path.encode("utf-8")).hexdigest()


def cache_file(key):
    return os.path.join(DIR, key + ".json")


def load(key):
    try:
        with open(cache_file(key), encoding="utf-8") as fh:
            return json.load(fh)
    except Exception:  # noqa: BLE001
        return None


def save(key, path, items):
    try:
        os.makedirs(DIR, exist_ok=True)
        tmp = f"{cache_file(key)}.{os.getpid()}.{threading.get_ident()}.tmp"   # never two writers on one file
        with open(tmp, "w", encoding="utf-8") as fh:
            json.dump({"v": 2, "path": path, "time": time.time(), "items": items}, fh)
        os.replace(tmp, cache_file(key))
    except Exception as error:  # noqa: BLE001
        log(f"save: {error}")


def rpc(method, params):
    answer = json.loads(xbmc.executeJSONRPC(json.dumps({"jsonrpc": "2.0", "id": 1, "method": method, "params": params})))
    if "error" in answer:
        raise RuntimeError(answer["error"].get("message", "error"))
    return answer.get("result") or {}


def fetch(path):
    """Items of the real path (a list of dicts as JSON-RPC gives them)."""
    for props in (PROPS, BASIC):
        try:
            result = rpc("Files.GetDirectory", {"directory": path, "media": "video", "properties": props})
            return result.get("files") or []
        except Exception as error:  # noqa: BLE001
            log(f"{path[:90]}: {error}")
    return []


def fetch_retry(path):
    items = fetch(path)
    if not items:
        xbmc.Monitor().waitForAbort(3)
        items = fetch(path)
    return enrich(items)


# ----------------------------------------------------------------------------- what JSON-RPC leaves out, from Seren's own database
SEREN_DB = xbmcvfs.translatePath("special://profile/addon_data/plugin.video.seren/traktSync.db")
TABLES = {"movie": "movies", "tvshow": "shows", "season": "seasons", "episode": "episodes"}
EXTRA_PROPS = {"rottentomatoes_rating": "RottenTomatoes_Rating", "metacritic_rating": "Metacritic_Rating",
               "rottentomatoes_image": "RottenTomatoes_Image"}


def action_args(url):
    try:
        query = urllib.parse.parse_qs(urllib.parse.urlsplit(url).query)
        raw = (query.get("action_args") or [""])[0]
        for _ in range(2):
            if raw[:3].lower() == "%7b":
                raw = urllib.parse.unquote(raw)
        return json.loads(raw) if raw.startswith("{") else {}
    except Exception:  # noqa: BLE001
        return {}


def enrich(items):
    """Ratings per site (IMDb, Trakt, TMDB), the show status and a few Seren properties, read from Seren's database
    (Seren keeps the details of every title it showed). Items Seren does not know stay as they are."""
    if not items or not os.path.exists(SEREN_DB):
        return items
    import pickle
    import sqlite3
    try:
        con = sqlite3.connect(f"file:{SEREN_DB}?mode=ro", uri=True, timeout=10)
    except Exception as error:  # noqa: BLE001
        log(f"seren db: {error}")
        return items
    try:
        for entry in items:
            args = action_args(entry.get("file") or "")
            table = TABLES.get(args.get("mediatype") or entry.get("type"))
            trakt_id = args.get("trakt_id")
            if not table or not trakt_id:
                continue
            try:
                row = con.execute(f"SELECT info FROM {table} WHERE trakt_id = ?", (int(trakt_id),)).fetchone()
            except Exception:  # noqa: BLE001 - another Seren version
                continue
            if not row or row[0] is None:
                continue
            info = row[0]
            if isinstance(info, (bytes, bytearray, memoryview)):
                try:
                    info = pickle.loads(bytes(info))
                except Exception:  # noqa: BLE001
                    continue
            if not isinstance(info, dict):
                continue
            ratings = {}
            for key, value in info.items():
                if key.startswith("rating.") and isinstance(value, dict) and value.get("rating"):
                    ratings[key.split(".", 1)[1]] = {"rating": value.get("rating"), "votes": value.get("votes") or 0}
            if ratings:
                entry["ratings"] = ratings
            status = info.get("status") or info.get("tvshow.status")
            if status:
                entry["status"] = status
            props = {name: str(info[key]) for key, name in EXTRA_PROPS.items() if info.get(key) not in (None, "")}
            if props:
                entry["props"] = props
    finally:
        con.close()
    return items


# ----------------------------------------------------------------------------- items back into list items
def seren_ids(url):
    """{'trakt_id': '123', ...} from the action_args of a Seren path."""
    try:
        query = urllib.parse.parse_qs(urllib.parse.urlsplit(url).query)
        raw = (query.get("action_args") or [""])[0]
        for _ in range(2):
            if raw.startswith("%7B") or raw.startswith("%7b"):
                raw = urllib.parse.unquote(raw)
        data = json.loads(raw) if raw.startswith("{") else {}
        return {k: str(v) for k, v in data.items() if k.endswith("_id") and v not in (None, "")}
    except Exception:  # noqa: BLE001
        return {}


def listitem(entry):
    li = xbmcgui.ListItem(entry.get("label") or entry.get("title") or "", offscreen=True)
    art = {k: v for k, v in (entry.get("art") or {}).items() if v}
    if art:
        li.setArt(art)
    tag = li.getVideoInfoTag()
    kind = entry.get("type") if entry.get("type") in ("movie", "tvshow", "season", "episode") else "video"
    tag.setMediaType(kind)
    dbid = entry.get("id")                         # a title from the Kodi library: without its id the info page
    if kind != "video" and isinstance(dbid, int) and dbid > 0:     # cannot find it (OK > info did nothing)
        try:
            tag.setDbId(dbid)
        except Exception:  # noqa: BLE001
            pass
    simple = (("title", tag.setTitle), ("plot", tag.setPlot), ("showtitle", tag.setTvShowTitle),
              ("mpaa", tag.setMpaa), ("tagline", tag.setTagLine), ("originaltitle", tag.setOriginalTitle),
              ("trailer", tag.setTrailer), ("premiered", tag.setPremiered), ("firstaired", tag.setFirstAired))
    for name, setter in simple:
        if entry.get(name):
            try:
                setter(str(entry[name]))
            except Exception:  # noqa: BLE001
                pass
    for name, setter in (("year", tag.setYear), ("season", tag.setSeason), ("episode", tag.setEpisode),
                         ("playcount", tag.setPlaycount), ("runtime", tag.setDuration)):
        value = entry.get(name)
        if isinstance(value, int) and value >= 0 and not (name in ("season", "episode") and value < 0):
            try:
                setter(value)
            except Exception:  # noqa: BLE001
                pass
    for name, setter in (("genre", tag.setGenres), ("studio", tag.setStudios), ("country", tag.setCountries),
                         ("director", tag.setDirectors), ("writer", tag.setWriters)):
        if entry.get(name):
            try:
                setter(list(entry[name]))
            except Exception:  # noqa: BLE001
                pass
    ratings = entry.get("ratings") or {}
    if ratings:
        try:
            default = next((k for k, v in ratings.items() if v.get("default")), "")
            tag.setRatings({k: (float(v.get("rating") or 0), int(v.get("votes") or 0)) for k, v in ratings.items()}, default)
        except Exception:  # noqa: BLE001
            pass
    elif entry.get("rating"):
        try:
            tag.setRating(float(entry["rating"]))
        except Exception:  # noqa: BLE001
            pass
    if entry.get("status"):
        try:
            tag.setTvShowStatus(str(entry["status"]))
        except Exception:  # noqa: BLE001
            pass
    for k, v in (entry.get("props") or {}).items():
        li.setProperty(k, v)
    if entry.get("uniqueid"):
        try:
            tag.setUniqueIDs({k: str(v) for k, v in entry["uniqueid"].items() if v})
        except Exception:  # noqa: BLE001
            pass
    resume = entry.get("resume") or {}
    if resume.get("position"):
        try:
            tag.setResumePoint(float(resume["position"]), float(resume.get("total") or 0))
        except Exception:  # noqa: BLE001
            pass
    for k, v in seren_ids(entry.get("file") or "").items():
        li.setProperty(k, v)
    folder = entry.get("filetype") == "directory"
    li.setProperty("IsPlayable", "false" if folder else "true")
    return entry.get("file") or "", li, folder


def answer(handle, items):
    kinds = [e.get("type") for e in items]
    content = "movies" if kinds.count("movie") > len(kinds) / 2 else "episodes" if kinds.count("episode") > len(kinds) / 2 \
        else "tvshows" if kinds.count("tvshow") > len(kinds) / 2 else "videos"
    xbmcplugin.setContent(handle, content)
    xbmcplugin.addDirectoryItems(handle, [listitem(e) for e in items], len(items))
    xbmcplugin.addSortMethod(handle, xbmcplugin.SORT_METHOD_NONE)
    xbmcplugin.endOfDirectory(handle, succeeded=True, cacheToDisc=False)


# ----------------------------------------------------------------------------- refresh in the background
def start_refresh(key, row):
    busy = HOME.getProperty(f"lucent.wb.{key}")
    if busy and time.time() - float(busy) < 120:
        return
    HOME.setProperty(f"lucent.wb.{key}", str(time.time()))
    xbmc.executebuiltin(f"RunScript({ADDON_ID},widget_refresh,{key},{row})")


def refresh(key, row):
    cache = load(key) or {}
    path = cache.get("path")
    try:
        if not path:
            return
        items = fetch_retry(path)
        if items:
            save(key, path, items)
            if items != cache.get("items"):
                HOME.setProperty(f"lucent.wr.{row}", str(time.time()))
        else:
            log(f"refresh gave nothing, keeping the saved row: {path[:90]}")
            save(key, path, cache.get("items") or [])          # try again after TTL, not at once
    finally:
        HOME.clearProperty(f"lucent.wb.{key}")


def mark_all_stale():
    try:
        os.makedirs(DIR, exist_ok=True)
        with open(STALE_FLAG, "w") as fh:
            fh.write(str(time.time()))
    except Exception:  # noqa: BLE001
        pass
    for row in range(1, 11):
        HOME.setProperty(f"lucent.wr.{row}", str(time.time()))


def stale_since():
    try:
        return os.path.getmtime(STALE_FLAG)
    except OSError:
        return 0


def show(handle, query):
    if query.lstrip("?").startswith("action=lib"):  # rows straight from Kodi's own library
        import libwidgets
        libwidgets.show(handle, query)
        return
    row = "0"
    path = ""
    q = query[1:] if query.startswith("?") else query
    if "path=" in q:
        head, path = q.split("path=", 1)
        for part in head.split("&"):
            if part.startswith("row="):
                row = part[4:]
    if path.lower().startswith(("plugin%3a", "special%3a", "videodb%3a")):
        path = urllib.parse.unquote(path)
    if not path:
        xbmcplugin.endOfDirectory(handle, succeeded=False, cacheToDisc=False)
        return
    if path.startswith(f"plugin://{ADDON_ID}/?action=lib"):
        import libwidgets                            # a library row: instant, no need to keep a copy
        libwidgets.show(handle, path.split("?", 1)[1])
        return
    key = key_of(path)
    cache = load(key)
    if cache and cache.get("items"):
        answer(handle, cache["items"])
        if cache.get("v") != 2:
            start_refresh(key, row)                      # saved by 1.4.0: fetch again with the ratings
            return
        if time.time() - cache.get("time", 0) > TTL or cache.get("time", 0) < stale_since():
            start_refresh(key, row)
        return
    items = fetch_retry(path)
    if items:
        save(key, path, items)
    answer(handle, items)


if __name__ == "__main__":
    show(int(sys.argv[1]), sys.argv[2] if len(sys.argv) > 2 else "")

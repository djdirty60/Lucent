import lib

lib.run(manual=True)

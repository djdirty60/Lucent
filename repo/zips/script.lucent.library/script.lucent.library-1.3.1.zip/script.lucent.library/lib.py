"""Seren (Trakt collection) -> .strm + .nfo files for the Kodi video library."""
import json
import os
import urllib.request
import pickle
import re
import sqlite3
import time
from concurrent.futures import ThreadPoolExecutor
from urllib.parse import urlencode
from xml.sax.saxutils import escape

import xbmc
import xbmcaddon
import xbmcgui
import xbmcvfs

ADDON = xbmcaddon.Addon()
ADDON_ID = ADDON.getAddonInfo("id")
NL = xbmc.getLanguage(xbmc.ISO_639_1).lower().startswith("nl")
SEREN_DB = xbmcvfs.translatePath("special://profile/addon_data/plugin.video.seren/traktSync.db")
OUT_SPECIAL = f"special://profile/addon_data/{ADDON_ID}/movies/"
OUT = xbmcvfs.translatePath(OUT_SPECIAL)
TV_SPECIAL = f"special://profile/addon_data/{ADDON_ID}/tvshows/"
TV_OUT = xbmcvfs.translatePath(TV_SPECIAL)
USE_SCRAPER = True      # Kodi's own TMDB scrapers fetch the details; the .nfo only holds the ids
USE_TMDB_FILL = False   # own TMDB requests: not needed with the scrapers
MARK = ".lucent-library"
ENABLED = xbmcvfs.translatePath(f"special://profile/addon_data/{ADDON_ID}/enabled")


def log(text):
    xbmc.log(f"[{ADDON_ID}] {text}", xbmc.LOGINFO)


def say(text, time_ms=6000):
    xbmcgui.Dialog().notification("Lucent Bibliotheek" if NL else "Lucent Library", text, xbmcgui.NOTIFICATION_INFO, time_ms)


def _load(value):
    if isinstance(value, (bytes, bytearray, memoryview)):
        try:
            return pickle.loads(bytes(value))
        except Exception:  # noqa: BLE001
            return None
    return value


def read_collection():
    """[(trakt_id, tmdb_id, imdb_id, info, art, cast, args, watched, collected_at)] of the collected movies."""
    if not os.path.exists(SEREN_DB):
        raise RuntimeError("seren-db")
    con = sqlite3.connect(f"file:{SEREN_DB}?mode=ro", uri=True, timeout=30)
    try:
        rows = con.execute(
            'SELECT trakt_id, tmdb_id, imdb_id, info, art, "cast", args, watched, collected_at FROM movies WHERE collected = 1'
        ).fetchall()
    finally:
        con.close()
    out, skipped = [], 0
    for trakt_id, tmdb_id, imdb_id, info, art, cast, args, watched, collected_at in rows:
        info, art, cast = _load(info), _load(art), _load(cast)
        if not isinstance(info, dict) or not info.get("title"):
            skipped += 1
            continue
        out.append((trakt_id, tmdb_id, imdb_id, info, art if isinstance(art, dict) else {}, cast if isinstance(cast, list) else [], args, watched, collected_at))
    return out, skipped


def safe_name(text):
    return re.sub(r"\s+", " ", re.sub(r'[<>:"/\\|?*\x00-\x1f]', "", text)).strip(" .")[:120] or "film"


def tag(name, value):
    if value in (None, "", [], {}):
        return ""
    return f"  <{name}>{escape(str(value))}</{name}>\n"


def rating_of(info):
    value = info.get("rating")
    votes = info.get("votes")
    if isinstance(value, dict):
        value, votes = value.get("rating"), value.get("votes")
    if value in (None, "", 0):
        for key, entry in info.items():
            if str(key).startswith("rating.") and isinstance(entry, dict) and entry.get("rating"):
                value, votes = entry.get("rating"), entry.get("votes")
                break
    try:
        return float(value), int(votes or 0)
    except (TypeError, ValueError):
        return None, 0


def strm_url(args):
    try:
        action_args = json.dumps(json.loads(args) if isinstance(args, str) else args, sort_keys=True)
    except Exception:  # noqa: BLE001
        action_args = args if isinstance(args, str) else json.dumps(args)
    return "plugin://plugin.video.seren/?" + urlencode(sorted({"action": "getSources", "action_args": action_args}.items()))


def ids_nfo(root, tmdb_id, imdb_id, trakt_id, extra=""):
    """Only the TMDB address: the format every Kodi scraper reads ('movie' or 'tv')."""
    kind = "movie" if root == "movie" else "tv"
    return f"https://www.themoviedb.org/{kind}/{tmdb_id}\n"


def nfo_of(trakt_id, tmdb_id, imdb_id, info, art, cast, watched, collected_at):
    if USE_SCRAPER and tmdb_id:
        return ids_nfo("movie", tmdb_id, imdb_id, trakt_id)
    title = info.get("title")
    x = ['<?xml version="1.0" encoding="UTF-8" standalone="yes"?>\n<movie>\n']
    x.append(tag("title", title))
    x.append(tag("originaltitle", info.get("originaltitle")))
    x.append(tag("year", info.get("year")))
    x.append(tag("plot", info.get("plot") or info.get("overview")))
    x.append(tag("outline", info.get("plotoutline")))
    x.append(tag("tagline", info.get("tagline")))
    duration = info.get("duration")
    if isinstance(duration, (int, float)) and duration > 0:
        x.append(tag("runtime", int(duration // 60)))
    x.append(tag("mpaa", info.get("mpaa")))
    x.append(tag("premiered", (info.get("premiered") or "")[:10]))
    for g in info.get("genre") or []:
        x.append(tag("genre", g))
    for s in info.get("studio") or []:
        x.append(tag("studio", s))
    for d in info.get("director") or []:
        x.append(tag("director", d))
    for w in info.get("writer") or []:
        x.append(tag("credits", w))
    value, votes = rating_of(info)
    if value:
        x.append(f'  <ratings><rating name="default" max="10" default="true"><value>{value}</value><votes>{votes}</votes></rating></ratings>\n')
    if tmdb_id:
        x.append(f'  <uniqueid type="tmdb" default="true">{tmdb_id}</uniqueid>\n')
    if imdb_id and str(imdb_id).startswith("tt"):
        x.append(f'  <uniqueid type="imdb">{escape(str(imdb_id))}</uniqueid>\n')
    x.append(f'  <uniqueid type="trakt">{trakt_id}</uniqueid>\n')
    if info.get("set"):
        x.append(f"  <set><name>{escape(str(info['set']))}</name></set>\n")
    x.append(tag("trailer", info.get("trailer")))
    if collected_at:
        x.append(tag("dateadded", str(collected_at).replace("T", " ")[:19]))
    x.append(tag("playcount", 1 if watched else 0))
    x.append(art_block(art))
    for i, person in enumerate(cast[:25]):
        if isinstance(person, dict) and person.get("name"):
            x.append("  <actor>\n" + tag("name", person.get("name")) + tag("role", person.get("role")) + tag("thumb", person.get("thumbnail"))
                     + f"    <order>{i}</order>\n  </actor>\n")
    x.append("</movie>\n")
    return "".join(x)


def write_if_changed(path, text):
    try:
        with open(path, "r", encoding="utf-8") as handle:
            if handle.read() == text:
                return False
    except OSError:
        pass
    with open(path, "w", encoding="utf-8") as handle:
        handle.write(text)
    return True


def export():
    """Write the files. Returns (written, total, skipped, removed)."""
    rows, skipped = read_collection()
    os.makedirs(OUT, exist_ok=True)
    with open(os.path.join(OUT, MARK), "w", encoding="utf-8") as handle:
        handle.write("Lucent Bibliotheek - map wordt door de add-on beheerd\n")
    wanted, written = {}, 0
    for trakt_id, tmdb_id, imdb_id, info, art, cast, args, watched, collected_at in rows:
        year = info.get("year")
        base = safe_name(f"{info.get('title')} ({year})" if year else str(info.get("title")))
        folder = base if base not in wanted else f"{base} [{trakt_id}]"
        wanted[folder] = True
        directory = os.path.join(OUT, folder)
        os.makedirs(directory, exist_ok=True)
        changed = write_if_changed(os.path.join(directory, f"{folder}.strm"), strm_url(args) + "\n")
        changed = write_if_changed(os.path.join(directory, f"{folder}.nfo"), nfo_of(trakt_id, tmdb_id, imdb_id, info, art, cast, watched, collected_at)) or changed
        written += 1 if changed else 0
    removed = 0
    for name in os.listdir(OUT):
        path = os.path.join(OUT, name)
        if os.path.isdir(path) and name not in wanted:
            for f in os.listdir(path):
                os.remove(os.path.join(path, f))
            os.rmdir(path)
            removed += 1
    log(f"export: {len(rows)} films, {written} changed, {skipped} without metadata, {removed} removed")
    return written, len(rows), skipped, removed


def rpc(method, params=None):
    request = {"jsonrpc": "2.0", "id": 1, "method": method, "params": params or {}}
    return json.loads(xbmc.executeJSONRPC(json.dumps(request))).get("result", {})


def source_added(special=OUT_SPECIAL):
    """True when this folder is a video source of Kodi."""
    real = xbmcvfs.translatePath(special).rstrip("/\\")
    for s in rpc("Files.GetSources", {"media": "video"}).get("sources", []):
        f = s.get("file", "")
        if f.rstrip("/") == special.rstrip("/") or xbmcvfs.translatePath(f).rstrip("/\\") == real:
            return True
    return False


def sync_watched():
    """Library -> files: marks the films Seren/Trakt knows as watched in the Kodi library as well."""
    try:
        movies = rpc("VideoLibrary.GetMovies", {"properties": ["file", "playcount"]}).get("movies", [])
        rows, _ = read_collection()
        seen = {}
        for trakt_id, _t, _i, info, _a, _c, args, watched, _d in rows:
            base = safe_name(f"{info.get('title')} ({info.get('year')})" if info.get("year") else str(info.get("title")))
            seen[base] = bool(watched)
        for movie in movies:
            f = movie.get("file", "")
            if f.endswith(".strm"):
                name = os.path.basename(f)[:-5]
                key = re.sub(r" \[\d+\]$", "", name)
                if seen.get(key) and not movie.get("playcount"):
                    rpc("VideoLibrary.SetMovieDetails", {"movieid": movie["movieid"], "playcount": 1})
    except Exception as error:  # noqa: BLE001
        log(f"watched sync: {error}")



TMDB_IMG = "https://image.tmdb.org/t/p/w500"
TMDB_STILL = "https://image.tmdb.org/t/p/w780"
TMDB_CACHE = xbmcvfs.translatePath(f"special://profile/addon_data/{ADDON_ID}/tmdb_seasons.json")
TMDB_KEYFILE = xbmcvfs.translatePath(f"special://profile/addon_data/{ADDON_ID}/tmdb_key.txt")
_TMDB = {}


def tmdb_key(ask=False):
    """The user's own free TMDB key: from Seren's setting when filled in, else from this add-on (asked once)."""
    try:
        key = xbmcaddon.Addon("plugin.video.seren").getSetting("tmdb.apikey").strip()
    except Exception:  # noqa: BLE001
        key = ""
    if key:
        return key
    try:
        with open(TMDB_KEYFILE, "r", encoding="utf-8") as handle:
            key = handle.read().strip()
    except OSError:
        key = ""
    if not key and ask:
        key = xbmcgui.Dialog().input(
            "TMDB API-sleutel (gratis op themoviedb.org > Instellingen > API)" if NL else "TMDB API key (free at themoviedb.org > Settings > API)"
        ).strip()
        if key:
            os.makedirs(os.path.dirname(TMDB_KEYFILE), exist_ok=True)
            with open(TMDB_KEYFILE, "w", encoding="utf-8") as handle:
                handle.write(key)
    return key


def tmdb_load_cache():
    if not _TMDB:
        try:
            with open(TMDB_CACHE, "r", encoding="utf-8") as handle:
                _TMDB.update(json.load(handle))
        except Exception:  # noqa: BLE001
            pass


def tmdb_season(tmdb_id, season, lang, key):
    """Season data from TMDB (poster, name, episodes with name / overview / still). Cached for a week."""
    ck = f"{tmdb_id}:{season}:{lang}"
    entry = _TMDB.get(ck)
    if entry and time.time() - entry.get("t", 0) < 7 * 86400:
        return entry.get("d") or {}
    url = f"https://api.themoviedb.org/3/tv/{tmdb_id}/season/{season}?language={lang}&api_key={key}"
    try:
        request = urllib.request.Request(url, headers={"User-Agent": "script.lucent.library (Kodi)"})
        with urllib.request.urlopen(request, timeout=15) as response:
            data = json.loads(response.read().decode("utf-8"))
    except Exception as error:  # noqa: BLE001
        log(f"tmdb {tmdb_id} s{season}: {str(error).replace(key, '***')}")
        return (entry or {}).get("d") or {}
    _TMDB[ck] = {"t": time.time(), "d": data}
    return data


def tmdb_fill(shows, ask=False):
    """Fill the gaps Seren left (season posters, episode text and pictures) from TMDB with the user's own key."""
    key = tmdb_key(ask)
    if not key:
        return 0, -1
    tmdb_load_cache()
    lang = "nl-NL" if NL else "en-US"
    pairs = sorted({(sh["tmdb_id"], ep[1]) for sh in shows.values() if sh.get("tmdb_id") for ep in sh["episodes"]})
    with ThreadPoolExecutor(max_workers=6) as pool:
        data = dict(zip(pairs, pool.map(lambda p: tmdb_season(p[0], p[1], lang, key), pairs)))
        if lang != "en-US":
            need = [p for p in pairs if any(not e.get("overview") for e in (data.get(p) or {}).get("episodes", []))]
            english = dict(zip(need, pool.map(lambda p: tmdb_season(p[0], p[1], "en-US", key), need)))
        else:
            english = {}
    try:
        os.makedirs(os.path.dirname(TMDB_CACHE), exist_ok=True)
        with open(TMDB_CACHE, "w", encoding="utf-8") as handle:
            json.dump(_TMDB, handle)
    except Exception as error:  # noqa: BLE001
        log(f"tmdb cache: {error}")
    gaps = 0
    for sh in shows.values():
        tid = sh.get("tmdb_id")
        if not tid:
            continue
        for season in {ep[1] for ep in sh["episodes"]}:
            d = data.get((tid, season)) or {}
            sart = sh["season_art"].setdefault(season, {})
            if not (sart.get("poster") or sart.get("season.poster")) and d.get("poster_path"):
                sart["poster"] = TMDB_IMG + d["poster_path"]
            if d.get("name"):
                sh.setdefault("season_names", {})[season] = d["name"]
        filled = []
        for trakt_id, season, number, info, art, args, watched, collected_at in sh["episodes"]:
            d = data.get((tid, season)) or {}
            de = next((e for e in d.get("episodes", []) if e.get("episode_number") == number), {})
            ee = next((e for e in (english.get((tid, season)) or {}).get("episodes", []) if e.get("episode_number") == number), {})
            info, art = dict(info or {}), dict(art or {})
            if not info.get("title") or str(info.get("title")).lower().startswith("episode"):
                info["title"] = de.get("name") or ee.get("name") or info.get("title")
            if not (info.get("plot") or info.get("overview")):
                info["plot"] = de.get("overview") or ee.get("overview") or ""
            if not (info.get("aired") or info.get("premiered")) and de.get("air_date"):
                info["aired"] = de["air_date"]
            if not info.get("duration") and de.get("runtime"):
                info["duration"] = int(de["runtime"]) * 60
            if not info.get("rating") and de.get("vote_average"):
                info["rating"], info["votes"] = de["vote_average"], de.get("vote_count") or 0
            if not art.get("thumb") and de.get("still_path"):
                art["thumb"] = TMDB_STILL + de["still_path"]
            if not info.get("plot"):
                gaps += 1
            filled.append((trakt_id, season, number, info, art, args, watched, collected_at))
        sh["episodes"] = filled
    return len(pairs), gaps


def read_shows():
    """{show_id: {...show..., 'episodes': [(trakt_id, season, number, info, art, args, watched, collected_at)]}} of collected episodes."""
    if not os.path.exists(SEREN_DB):
        raise RuntimeError("seren-db")
    con = sqlite3.connect(f"file:{SEREN_DB}?mode=ro", uri=True, timeout=30)
    try:
        eps = con.execute(
            "SELECT trakt_id, trakt_show_id, season, number, info, art, args, watched, collected_at FROM episodes WHERE collected = 1 AND season > 0"
        ).fetchall()
        ids = sorted({e[1] for e in eps})
        shows = {}
        for i in range(0, len(ids), 500):
            chunk = ids[i:i + 500]
            for row in con.execute(
                f'SELECT trakt_id, tmdb_id, tvdb_id, imdb_id, info, art, "cast" FROM shows WHERE trakt_id IN ({",".join("?" * len(chunk))})', chunk
            ):
                shows[row[0]] = row
        season_art = {}
        for i in range(0, len(ids), 500):
            chunk = ids[i:i + 500]
            for sid, snum, sart in con.execute(
                f"SELECT trakt_show_id, season, art FROM seasons WHERE trakt_show_id IN ({','.join('?' * len(chunk))})", chunk
            ):
                loaded = _load(sart)
                if isinstance(loaded, dict):
                    season_art[(sid, snum)] = loaded
    finally:
        con.close()
    out = {}
    for trakt_id, show_id, season, number, info, art, args, watched, collected_at in eps:
        row = shows.get(show_id)
        if not row:
            continue
        show = out.get(show_id)
        if show is None:
            sinfo, sart, scast = _load(row[4]), _load(row[5]), _load(row[6])
            if not isinstance(sinfo, dict) or not sinfo.get("title"):
                continue
            show = out[show_id] = {"trakt_id": show_id, "tmdb_id": row[1], "tvdb_id": row[2], "imdb_id": row[3], "info": sinfo,
                                   "art": sart if isinstance(sart, dict) else {}, "cast": scast if isinstance(scast, list) else [], "episodes": [], "season_art": {}}
        if (show_id, season) in season_art:
            show["season_art"][season] = season_art[(show_id, season)]
        einfo, eart = _load(info), _load(art)
        show["episodes"].append((trakt_id, season, number, einfo if isinstance(einfo, dict) else {}, eart if isinstance(eart, dict) else {},
                                 args, watched, collected_at))
    return out


ART_KINDS = ("poster", "banner", "clearlogo", "clearart", "landscape", "discart", "keyart")


def art_block(art, episode=False):
    """Kodi reads artwork from <thumb aspect="..."> and <fanart><thumb> (not from an <art> tag)."""
    def good(v):
        return isinstance(v, str) and v.startswith(("http", "special:", "/"))
    out = ""
    for kind in ART_KINDS:
        if good(art.get(kind)):
            out += f'  <thumb aspect="{kind}">{escape(art[kind])}</thumb>\n'
    if episode and good(art.get("thumb")):
        out += f"  <thumb>{escape(art['thumb'])}</thumb>\n"
    elif episode and good(art.get("fanart")):
        out += f"  <thumb>{escape(art['fanart'])}</thumb>\n"
    if good(art.get("fanart")):
        out += f"  <fanart><thumb>{escape(art['fanart'])}</thumb></fanart>\n"
    return out


def actors_block(cast):
    out = ""
    for i, person in enumerate(cast[:25]):
        if isinstance(person, dict) and person.get("name"):
            out += "  <actor>\n" + tag("name", person.get("name")) + tag("role", person.get("role")) + tag("thumb", person.get("thumbnail")) + f"    <order>{i}</order>\n  </actor>\n"
    return out


def tvshow_nfo(show):
    info = show["info"]
    if USE_SCRAPER and show.get("tmdb_id"):
        extra = f'  <uniqueid type="tvdb">{show["tvdb_id"]}</uniqueid>\n' if show.get("tvdb_id") else ""
        return ids_nfo("tvshow", show.get("tmdb_id"), show.get("imdb_id"), show["trakt_id"], extra)
    x = ['<?xml version="1.0" encoding="UTF-8" standalone="yes"?>\n<tvshow>\n']
    x.append(tag("title", info.get("title")))
    x.append(tag("originaltitle", info.get("originaltitle")))
    x.append(tag("year", info.get("year")))
    x.append(tag("plot", info.get("plot") or info.get("overview")))
    x.append(tag("mpaa", info.get("mpaa")))
    x.append(tag("premiered", (info.get("premiered") or "")[:10]))
    x.append(tag("status", info.get("status")))
    for g in info.get("genre") or []:
        x.append(tag("genre", g))
    for s in info.get("studio") or []:
        x.append(tag("studio", s))
    value, votes = rating_of(info)
    if value:
        x.append(f'  <ratings><rating name="default" max="10" default="true"><value>{value}</value><votes>{votes}</votes></rating></ratings>\n')
    if show.get("tvdb_id"):
        x.append(f'  <uniqueid type="tvdb" default="true">{show["tvdb_id"]}</uniqueid>\n')
    if show.get("tmdb_id"):
        x.append(f'  <uniqueid type="tmdb">{show["tmdb_id"]}</uniqueid>\n')
    if show.get("imdb_id") and str(show["imdb_id"]).startswith("tt"):
        x.append(f'  <uniqueid type="imdb">{escape(str(show["imdb_id"]))}</uniqueid>\n')
    x.append(f'  <uniqueid type="trakt">{show["trakt_id"]}</uniqueid>\n')
    x.append(art_block(show["art"]))
    for number, sart in sorted(show.get("season_art", {}).items()):
        poster = sart.get("poster") or sart.get("season.poster")
        if isinstance(poster, str) and poster.startswith(("http", "special:", "/")):
            x.append(f'  <thumb type="season" season="{int(number)}" aspect="poster">{escape(poster)}</thumb>\n')
    for number, name in sorted(show.get("season_names", {}).items()):
        if name and not str(name).lower().startswith(("season", "seizoen")):
            x.append(f'  <namedseason number="{int(number)}">{escape(str(name))}</namedseason>\n')
    x.append(actors_block(show["cast"]))
    x.append("</tvshow>\n")
    return "".join(x)


def episode_nfo(show, trakt_id, season, number, info, art, watched, collected_at):
    x = ['<?xml version="1.0" encoding="UTF-8" standalone="yes"?>\n<episodedetails>\n']
    x.append(tag("title", info.get("title") or f"Episode {number}"))
    x.append(tag("showtitle", show["info"].get("title")))
    x.append(tag("season", season))
    x.append(tag("episode", number))
    x.append(tag("plot", info.get("plot") or info.get("overview")))
    duration = info.get("duration")
    if isinstance(duration, (int, float)) and duration > 0:
        x.append(tag("runtime", int(duration // 60)))
    x.append(tag("aired", (info.get("aired") or info.get("premiered") or "")[:10]))
    value, votes = rating_of(info)
    if value:
        x.append(f'  <ratings><rating name="default" max="10" default="true"><value>{value}</value><votes>{votes}</votes></rating></ratings>\n')
    x.append(f'  <uniqueid type="trakt" default="true">{trakt_id}</uniqueid>\n')
    if collected_at:
        x.append(tag("dateadded", str(collected_at).replace("T", " ")[:19]))
    x.append(tag("playcount", 1 if watched else 0))
    x.append(art_block(art, episode=True))
    x.append("</episodedetails>\n")
    return "".join(x)


CHANGED_SHOW_IDS = set()


def export_shows(ask_key=False):
    """Write the series files. Returns (changed, shows, episodes, removed)."""
    shows = read_shows()
    try:
        if USE_TMDB_FILL:
            asked, gaps = tmdb_fill(shows, ask_key)
            log(f"tmdb: {asked} seasons, episodes without text: {gaps}")
    except Exception as error:  # noqa: BLE001
        log(f"tmdb fill failed: {error}")
    os.makedirs(TV_OUT, exist_ok=True)
    with open(os.path.join(TV_OUT, MARK), "w", encoding="utf-8") as handle:
        handle.write("Lucent Bibliotheek - map wordt door de add-on beheerd\n")
    wanted, changed, episodes = {}, 0, 0
    for show in shows.values():
        year = show["info"].get("year")
        base = safe_name(f"{show['info'].get('title')} ({year})" if year else str(show["info"].get("title")))
        folder = base if base not in wanted else f"{base} [{show['trakt_id']}]"
        wanted[folder] = set()
        root = os.path.join(TV_OUT, folder)
        os.makedirs(root, exist_ok=True)
        show_changed = write_if_changed(os.path.join(root, "tvshow.nfo"), tvshow_nfo(show))
        changed += 1 if show_changed else 0
        for trakt_id, season, number, info, art, args, watched, collected_at in show["episodes"]:
            sdir = f"Season {int(season):02d}"
            os.makedirs(os.path.join(root, sdir), exist_ok=True)
            name = f"{folder} - S{int(season):02d}E{int(number):02d}"
            wanted[folder].add(os.path.join(sdir, name))
            a = write_if_changed(os.path.join(root, sdir, f"{name}.strm"), strm_url(args) + "\n")
            nfo_path = os.path.join(root, sdir, f"{name}.nfo")
            if USE_SCRAPER and show.get("tmdb_id"):
                b = False
                if os.path.exists(nfo_path):
                    os.remove(nfo_path)
                    b = True
            else:
                b = write_if_changed(nfo_path, episode_nfo(show, trakt_id, season, number, info, art, watched, collected_at))
            changed += 1 if (a or b) else 0
            show_changed = show_changed or a or b
            episodes += 1
        if show_changed:
            CHANGED_SHOW_IDS.add(str(show["trakt_id"]))
    removed = 0
    for folder in os.listdir(TV_OUT):
        path = os.path.join(TV_OUT, folder)
        if not os.path.isdir(path):
            continue
        if folder not in wanted:
            for r, d, f in os.walk(path, topdown=False):
                for n in f:
                    os.remove(os.path.join(r, n))
                os.rmdir(r)
            removed += 1
            continue
        for sdir in os.listdir(path):
            sp = os.path.join(path, sdir)
            if os.path.isdir(sp):
                for n in os.listdir(sp):
                    if os.path.join(sdir, os.path.splitext(n)[0]) not in wanted[folder]:
                        os.remove(os.path.join(sp, n))
                        removed += 1
                if not os.listdir(sp):
                    os.rmdir(sp)
    log(f"export shows: {len(shows)} series, {episodes} episodes, {changed} changed, {removed} removed")
    return changed, len(shows), episodes, removed


def sync_watched_episodes():
    try:
        eps = rpc("VideoLibrary.GetEpisodes", {"properties": ["file", "playcount"]}).get("episodes", [])
        seen = {}
        for show in read_shows().values():
            year = show["info"].get("year")
            base = safe_name(f"{show['info'].get('title')} ({year})" if year else str(show["info"].get("title")))
            for trakt_id, season, number, info, art, args, watched, collected_at in show["episodes"]:
                seen[f"{base} - S{int(season):02d}E{int(number):02d}"] = bool(watched)
        for ep in eps:
            f = ep.get("file", "")
            if f.endswith(".strm"):
                key = re.sub(r" \[\d+\]( - S\d+E\d+)$", r"\1", os.path.basename(f)[:-5])
                if seen.get(key) and not ep.get("playcount"):
                    rpc("VideoLibrary.SetEpisodeDetails", {"episodeid": ep["episodeid"], "playcount": 1})
    except Exception as error:  # noqa: BLE001
        log(f"watched sync episodes: {error}")


def refresh_missing_art():
    """Items that Kodi imported before the artwork was in the files: read their files again."""
    try:
        real = ADDON_ID
        todo = 0
        tried_path = xbmcvfs.translatePath(f"special://profile/addon_data/{ADDON_ID}/art_tried.json")
        try:
            tried = set(json.load(open(tried_path)))
        except Exception:  # noqa: BLE001
            tried = set()
        for m in rpc("VideoLibrary.GetMovies", {"properties": ["art", "file"]}).get("movies", []):
            if real in m.get("file", "") and not (m.get("art") or {}).get("poster") and f"m{m['movieid']}" not in tried:
                tried.add(f"m{m['movieid']}")
                rpc("VideoLibrary.RefreshMovie", {"movieid": m["movieid"], "ignorenfo": False})
                todo += 1
        for t in rpc("VideoLibrary.GetTVShows", {"properties": ["art", "file"]}).get("tvshows", []):
            if real in t.get("file", "") and not (t.get("art") or {}).get("poster") and f"t{t['tvshowid']}" not in tried:
                tried.add(f"t{t['tvshowid']}")
                rpc("VideoLibrary.RefreshTVShow", {"tvshowid": t["tvshowid"], "ignorenfo": False, "refreshepisodes": True})
                todo += 1
        with open(tried_path, "w") as handle:
            json.dump(sorted(tried), handle)
        log(f"refresh art: {todo} items")
        return todo
    except Exception as error:  # noqa: BLE001
        log(f"refresh art: {error}")
        return 0


def refresh_changed_shows():
    """Series whose files changed (more text or pictures): let Kodi read them again."""
    if not CHANGED_SHOW_IDS:
        return 0
    done = 0
    try:
        for t in rpc("VideoLibrary.GetTVShows", {"properties": ["file", "uniqueid"]}).get("tvshows", []):
            if ADDON_ID in t.get("file", "") and str((t.get("uniqueid") or {}).get("trakt", "")) in CHANGED_SHOW_IDS:
                rpc("VideoLibrary.RefreshTVShow", {"tvshowid": t["tvshowid"], "ignorenfo": False, "refreshepisodes": True})
                done += 1
    except Exception as error:  # noqa: BLE001
        log(f"refresh changed shows: {error}")
    log(f"refresh changed shows: {done}")
    return done


def set_covers():
    """A movie set gets the poster and background of its first film (Kodi does not read set artwork from .nfo files)."""
    done = 0
    try:
        for st in rpc("VideoLibrary.GetMovieSets", {"properties": ["art"]}).get("sets", []):
            art = st.get("art") or {}
            if art.get("poster"):
                continue
            detail = rpc("VideoLibrary.GetMovieSetDetails", {"setid": st["setid"], "properties": ["art"],
                                                             "movies": {"properties": ["art", "year"], "sort": {"method": "year"}}}).get("setdetails", {})
            for movie in detail.get("movies", []):
                marts = movie.get("art") or {}
                if marts.get("poster"):
                    new = {"poster": marts["poster"]}
                    if marts.get("fanart"):
                        new["fanart"] = marts["fanart"]
                    if marts.get("clearlogo"):
                        new["clearlogo"] = marts["clearlogo"]
                    rpc("VideoLibrary.SetMovieSetDetails", {"setid": st["setid"], "art": new})
                    done += 1
                    break
    except Exception as error:  # noqa: BLE001
        log(f"set covers: {error}")
    log(f"set covers: {done} sets")
    return done


def good_url(v):
    return isinstance(v, str) and v.startswith(("http", "special:", "/"))


def show_covers():
    """Series and seasons without artwork get it straight from Seren's data (does not depend on the .nfo being read)."""
    done = 0
    try:
        shows = read_shows()
        by_trakt = {str(sh["trakt_id"]): sh for sh in shows.values()}
        for t in rpc("VideoLibrary.GetTVShows", {"properties": ["art", "file", "uniqueid"]}).get("tvshows", []):
            if ADDON_ID not in t.get("file", ""):
                continue
            sh = by_trakt.get(str((t.get("uniqueid") or {}).get("trakt", "")))
            if not sh:
                continue
            new = {k: sh["art"][k] for k in ART_KINDS + ("fanart",) if good_url(sh["art"].get(k))}
            if new and not (t.get("art") or {}).get("poster"):
                rpc("VideoLibrary.SetTVShowDetails", {"tvshowid": t["tvshowid"], "art": new})
                done += 1
            for season in rpc("VideoLibrary.GetSeasons", {"tvshowid": t["tvshowid"], "properties": ["season", "art"]}).get("seasons", []):
                if (season.get("art") or {}).get("poster"):
                    continue
                sart = sh.get("season_art", {}).get(season.get("season"), {})
                poster = sart.get("poster") or sart.get("season.poster") or sh["art"].get("poster")
                if good_url(poster):
                    rpc("VideoLibrary.SetSeasonDetails", {"seasonid": season["seasonid"], "art": {"poster": poster}})
                    done += 1
    except Exception as error:  # noqa: BLE001
        log(f"show covers: {error}")
    log(f"show covers: {done}")
    return done


def run(manual=True):
    title = "Lucent Bibliotheek" if NL else "Lucent Library"
    try:
        written, total, skipped, removed = export()
        tv_changed, tv_shows, tv_eps, tv_removed = export_shows(ask_key=manual)
    except RuntimeError:
        if manual:
            xbmcgui.Dialog().ok(title, "Seren heeft nog geen gegevens. Open eerst in Seren je Trakt-collectie en probeer het dan opnieuw."
                                if NL else "Seren has no data yet. First open your Trakt collection in Seren, then try again.")
        return
    except Exception as error:  # noqa: BLE001
        log(f"export failed: {error}")
        if manual:
            say(("Mislukt: " if NL else "Failed: ") + str(error)[:60])
        return
    os.makedirs(os.path.dirname(ENABLED), exist_ok=True)
    open(ENABLED, "w").close()
    missing = [p for p in (OUT_SPECIAL, TV_SPECIAL) if not source_added(p)]
    if missing and manual:
        lines = "\n".join(missing)
        xbmcgui.Dialog().ok(title, (f"Klaar: {total} films en {tv_shows} series ({tv_eps} afleveringen) klaargezet.\nVoeg eenmalig deze map(pen) als bron toe in Kodi:\n{lines}" if NL
                                    else f"Done: {total} movies and {tv_shows} series ({tv_eps} episodes) prepared.\nAdd this folder(s) as a source in Kodi (once):\n{lines}"))
    scanned = False
    for path in (OUT_SPECIAL, TV_SPECIAL):
        if path not in missing:
            xbmc.executebuiltin(f'UpdateLibrary(video,"{path}")')
            scanned = True
            mon = xbmc.Monitor()
            time.sleep(3)
            for _ in range(600):
                if mon.abortRequested() or not xbmc.getCondVisibility("Library.IsScanningVideo"):
                    break
                mon.waitForAbort(2)
    if scanned:
        sync_watched()
        sync_watched_episodes()
        if not USE_SCRAPER:
            refresh_missing_art()
            refresh_changed_shows()
            set_covers()
            show_covers()
        xbmc.executebuiltin("CleanLibrary(video,false)")
        if manual or written or removed or tv_changed or tv_removed:
            say(f"{total} films, {tv_shows} series" if NL else f"{total} movies, {tv_shows} series")

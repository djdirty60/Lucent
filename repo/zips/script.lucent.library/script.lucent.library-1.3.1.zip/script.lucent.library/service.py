"""At Kodi start (after a minute) refresh the library files - only after the first manual run."""
import os

import xbmc

import lib

monitor = xbmc.Monitor()
if not monitor.waitForAbort(90) and os.path.exists(lib.ENABLED):
    lib.run(manual=False)

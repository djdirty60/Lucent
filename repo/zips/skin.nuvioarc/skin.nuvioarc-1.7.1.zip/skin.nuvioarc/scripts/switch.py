# -*- coding: utf-8 -*-
"""Nuvio Arc is now called Lucent (a separate add-on, skin.lucent, installed with this update).
Offer to switch over once per Kodi start; Lucent takes over all settings by itself."""
import json

import xbmc
import xbmcgui

HOME = xbmcgui.Window(10000)
_NL = xbmc.getLanguage(xbmc.ISO_639_1) == "nl"

if not HOME.getProperty("nuvio.switch.asked") and xbmc.getCondVisibility("System.HasAddon(skin.lucent)"):
    HOME.setProperty("nuvio.switch.asked", "1")
    text = ("Nuvio Arc heet nu Lucent en is als nieuwe skin geïnstalleerd. Je menu, widgets en instellingen gaan mee.[CR][CR]"
            "Nu overschakelen naar Lucent?" if _NL else
            "Nuvio Arc is now called Lucent and has been installed as a new skin. Your menu, widgets and settings come along.[CR][CR]"
            "Switch to Lucent now?")
    if xbmcgui.Dialog().yesno("Lucent", text):
        xbmc.executeJSONRPC(json.dumps({"jsonrpc": "2.0", "id": 1, "method": "Settings.SetSettingValue",
                                        "params": {"setting": "lookandfeel.skin", "value": "skin.lucent"}}))

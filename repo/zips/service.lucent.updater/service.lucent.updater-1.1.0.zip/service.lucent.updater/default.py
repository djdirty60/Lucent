# -*- coding: utf-8 -*-
# Gestart als je de add-on opent, of via de testknop in de instellingen.
import sys
from resources.lib import updater

if len(sys.argv) > 1 and sys.argv[1] == "test":
    updater.run_test()
else:
    updater.run_check(manual=True)

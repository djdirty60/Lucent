# -*- coding: utf-8 -*-
"""Update-melding voor het Seren-thema Lucent.

Kijkt op GitHub naar de nieuwste Release van djdirty60/Seren-Thema,
vergelijkt die met de geinstalleerde versie en laat een pop-up zien met
de release-notes. Het bijwerken zelf doet Seren (checkSkinUpdates).
"""
import json
import os
import re
import urllib.request

import xbmc
import xbmcaddon
import xbmcgui
import xbmcvfs

ADDON_ID = "service.lucent.updater"
REPO = "djdirty60/Seren-Thema"
API_URL = "https://api.github.com/repos/%s/releases/latest" % REPO
# Het thema heet nu "Lucent"; "Nuvio Arc V2" is de oude naam (oudere installaties).
SKIN_NAMES = ("lucent", "nuvio arc v2")
HEADING = "Lucent"
SEREN_ID = "plugin.video.seren"
SEREN_UPDATE = "RunPlugin(plugin://plugin.video.seren/?action=checkSkinUpdates)"

SEARCH_ROOTS = (
    "special://profile/addon_data/plugin.video.seren/",
    "special://home/addons/plugin.video.seren/",
)


# --------------------------------------------------------------- helpers
def _addon():
    # Steeds opnieuw ophalen, zodat gewijzigde instellingen meteen gelden.
    return xbmcaddon.Addon(ADDON_ID)


def log(msg, level=xbmc.LOGINFO):
    xbmc.log("[%s] %s" % (ADDON_ID, msg), level)


def get_bool(setting_id, default=True):
    try:
        return _addon().getSettingBool(setting_id)
    except Exception:
        return default


def interval_hours():
    try:
        return max(1, int(_addon().getSettingInt("interval")))
    except Exception:
        return 6


def parse_version(text):
    """'v1.3.10' -> (1, 3, 10). Lege of rare tekst -> ()."""
    parts = re.findall(r"\d+", text or "")
    return tuple(int(p) for p in parts[:4])


def _state_path():
    profile = xbmcvfs.translatePath(_addon().getAddonInfo("profile"))
    if not os.path.isdir(profile):
        os.makedirs(profile, exist_ok=True)
    return os.path.join(profile, "state.json")


def load_state():
    try:
        with open(_state_path(), "r", encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return {}


def save_state(state):
    try:
        with open(_state_path(), "w", encoding="utf-8") as f:
            json.dump(state, f, indent=2)
    except Exception as e:
        log("Kon status niet opslaan: %s" % e, xbmc.LOGWARNING)


def _get_json(url):
    req = urllib.request.Request(
        url,
        headers={
            "User-Agent": "Kodi-%s" % ADDON_ID,
            "Accept": "application/vnd.github+json",
        },
    )
    with urllib.request.urlopen(req, timeout=15) as resp:
        return json.loads(resp.read().decode("utf-8"))


# ----------------------------------------------------------- GitHub info
def fetch_latest():
    """Geeft dict met version/title/notes, of None als het niet lukt."""
    try:
        data = _get_json(API_URL)
    except Exception as e:
        log("GitHub niet bereikbaar: %s" % e, xbmc.LOGWARNING)
        return None

    tag = (data.get("tag_name") or "").strip()
    version = tag.lstrip("vV")

    # Voorkeur: het versienummer uit meta.json in de Release (dat gebruikt
    # Seren ook). Lukt dat niet, dan het tag-nummer.
    for asset in data.get("assets") or []:
        if asset.get("name") == "meta.json":
            try:
                meta = _get_json(asset.get("browser_download_url"))
                if meta.get("version"):
                    version = str(meta["version"]).strip()
            except Exception as e:
                log("meta.json uit Release niet te lezen: %s" % e, xbmc.LOGWARNING)
            break

    if not parse_version(version):
        log("Geen geldig versienummer in nieuwste Release (%r)" % tag, xbmc.LOGWARNING)
        return None

    return {
        "version": version,
        "title": (data.get("name") or tag or version).strip(),
        "notes": data.get("body") or "",
    }


# ------------------------------------------------------ installed version
def find_installed_version():
    """Versie van het geinstalleerde thema in Seren (de hoogste, als er meer staan)."""
    found = find_installed_themes()
    if not found:
        return None
    return max(found.values(), key=parse_version)


def find_installed_themes():
    """Alle geinstalleerde versies van dit thema in Seren: {naam in meta.json: versie}.
    'Lucent' is de huidige naam; 'Nuvio Arc V2' is de oude naam (oudere installaties)."""
    found = {}
    for root in SEARCH_ROOTS:
        path = xbmcvfs.translatePath(root)
        if not os.path.isdir(path):
            continue
        for dirpath, dirnames, filenames in os.walk(path):
            # Grote of irrelevante mappen overslaan
            dirnames[:] = [d for d in dirnames
                           if d.lower() not in ("cache", "temp", "tmp", "__pycache__")]
            if "meta.json" not in filenames:
                continue
            try:
                with open(os.path.join(dirpath, "meta.json"), "r", encoding="utf-8") as f:
                    meta = json.load(f)
            except Exception:
                continue
            name = str(meta.get("skin_name", "")).strip()
            version = str(meta.get("version", "")).strip()
            if name.lower() in SKIN_NAMES and version:
                if name not in found or parse_version(version) > parse_version(found[name]):
                    found[name] = version
    return found


# ------------------------------------------------------ Seren's eigen label
def sync_seren_label():
    """Seren werkt bij een update de bestanden van het thema bij, maar laat de regel 'Thema in gebruik'
    in zijn instellingen op de oude versie staan (die past Seren alleen aan bij 'Thema wisselen').
    Daardoor lijkt het alsof je na elke update moet wisselen. Deze functie zet de versie daar goed."""
    try:
        seren = xbmcaddon.Addon(SEREN_ID)
        label = seren.getSetting("skin.active") or ""
    except Exception:
        return
    name, sep, old = label.rpartition(" - ")
    if not sep or name.strip().lower() not in SKIN_NAMES:
        return  # een ander thema is actief: niets aan doen
    version = find_installed_themes().get(name.strip())
    if version and version != old.strip():
        try:
            seren.setSetting("skin.active", "%s - %s" % (name.strip(), version))
            log("Seren-label bijgewerkt: %s -> %s" % (old.strip(), version))
        except Exception as e:
            log("Kon Seren-label niet bijwerken: %s" % e, xbmc.LOGWARNING)


def old_theme_warning(state):
    """Staat naast 'Lucent' ook nog het oude 'Nuvio Arc V2' in Seren, dan krijgt dat oude thema geen updates
    meer. Eén keer uitleggen hoe je het opruimt."""
    found = find_installed_themes()
    has_old = any(n.lower() == "nuvio arc v2" for n in found)
    has_new = any(n.lower() == "lucent" for n in found)
    if not has_old or state.get("old_warned"):
        return
    state["old_warned"] = True
    tekst = ("In Seren staat nog het oude thema [B]Nuvio Arc V2[/B]. Dat heet nu [B]Lucent[/B], en alleen "
             "Lucent krijgt nog updates.\n\n"
             "Ruim het één keer op:\n"
             "1. Seren > Gereedschap > Instellingen openen > Interface\n"
             "2. Thema wisselen: kies [B]Lucent[/B]%s\n"
             "3. Thema verwijderen: kies [B]Nuvio Arc V2[/B]") % ("" if has_new else
                                                                 " (staat het er niet? Installeer Lucent eerst opnieuw)")
    xbmcgui.Dialog().textviewer(HEADING + " – oud thema gevonden", tekst)


# ------------------------------------------------------------- tekst
def format_notes(markdown):
    """Zet GitHub-markdown om naar Kodi-opmaak."""
    out = []
    for line in (markdown or "").replace("\r", "").split("\n"):
        s = line.rstrip()
        m = re.match(r"^\s*#{1,6}\s*(.+?)\s*#*\s*$", s)
        if m:
            if out and out[-1] != "":
                out.append("")
            out.append("[B]%s[/B]" % m.group(1))
            continue
        s = re.sub(r"^(\s*)[-*+]\s+", r"\1  •  ", s)
        s = re.sub(r"\*\*(.+?)\*\*", r"[B]\1[/B]", s)
        s = re.sub(r"__(.+?)__", r"[B]\1[/B]", s)
        s = re.sub(r"`([^`]+)`", r"\1", s)
        s = re.sub(r"!\[[^\]]*\]\([^)]*\)", "", s)          # plaatjes weg
        s = re.sub(r"\[([^\]]+)\]\([^)]+\)", r"\1", s)       # links -> tekst
        out.append(s)
    text = "\n".join(out).strip()
    return text or "Bij deze versie staat geen beschrijving."


# ------------------------------------------------------------- pop-ups
def show_update_available(latest, installed, test=False):
    kop = "%s – nieuwe versie %s" % (HEADING, latest["version"])
    if test:
        kop += "  [TEST]"
    regels = []
    if installed:
        regels.append("Je hebt nu versie [B]%s[/B]. Versie [B]%s[/B] staat klaar."
                      % (installed, latest["version"]))
    else:
        regels.append("Versie [B]%s[/B] staat klaar." % latest["version"])
    regels.append("")
    regels.append("[B]Wat is er nieuw of veranderd:[/B]")
    regels.append("")
    regels.append(format_notes(latest["notes"]))
    xbmcgui.Dialog().textviewer(kop, "\n".join(regels))

    if xbmc.getCondVisibility("System.HasAddon(%s)" % SEREN_ID):
        nu = xbmcgui.Dialog().yesno(
            HEADING,
            "Wil je het thema nu bijwerken?\n"
            "Seren haalt dan de nieuwe versie op en installeert die.",
            nolabel="Later",
            yeslabel="Nu bijwerken",
        )
        if nu:
            xbmc.executebuiltin(SEREN_UPDATE)
            wait_for_update(latest)


def wait_for_update(latest, seconds=180):
    """Seren werkt op de achtergrond bij; wacht tot de nieuwe versie er staat en zet dan Seren's label goed."""
    monitor = xbmc.Monitor()
    target = parse_version(latest["version"])
    for _ in range(seconds // 2):
        if monitor.waitForAbort(2):
            return
        installed = find_installed_version()
        if installed and parse_version(installed) >= target:
            sync_seren_label()
            state = load_state()
            state["seen"] = installed
            state["notified"] = latest["version"]
            save_state(state)
            return


def show_whats_new(latest):
    kop = "%s – bijgewerkt naar %s" % (HEADING, latest["version"])
    tekst = "[B]Dit is er nieuw:[/B]\n\n" + format_notes(latest["notes"])
    xbmcgui.Dialog().textviewer(kop, tekst)


# ------------------------------------------------------------- hoofdlogica
def run_check(manual=False):
    latest = fetch_latest()
    if latest is None:
        if manual:
            xbmcgui.Dialog().ok(HEADING, "GitHub is nu niet bereikbaar.\nProbeer het later nog eens.")
        return

    sync_seren_label()
    installed = find_installed_version()
    state = load_state()
    first_run = not state
    remote_v = parse_version(latest["version"])
    if not manual:
        old_theme_warning(state)
    log("GitHub: %s, geinstalleerd: %s" % (latest["version"], installed))

    # Handmatig geopend: altijd iets laten zien
    if manual:
        if installed and parse_version(installed) >= remote_v:
            kop = "%s – versie %s (nieuwste)" % (HEADING, installed)
            xbmcgui.Dialog().textviewer(
                kop, "Je hebt de nieuwste versie.\n\n[B]Wat er in deze versie zit:[/B]\n\n"
                + format_notes(latest["notes"]))
        else:
            show_update_available(latest, installed)
        state["notified"] = latest["version"]
        if installed:
            state["seen"] = installed
        save_state(state)
        return

    # 1) Er is een nieuwere versie dan geinstalleerd
    if installed is None or parse_version(installed) < remote_v:
        if installed is None and first_run:
            # Thema niet gevonden en eerste keer: alleen onthouden
            state["notified"] = latest["version"]
        elif state.get("notified") != latest["version"] and get_bool("notify_new", True):
            show_update_available(latest, installed)
            state["notified"] = latest["version"]
        save_state(state)
        return

    # 2) Geinstalleerd is (minstens) de nieuwste versie
    if first_run:
        # Eerste keer na installeren van deze add-on: niets tonen
        state["seen"] = installed
        state["notified"] = latest["version"]
    elif state.get("seen") != installed:
        # Alleen tonen als de wijzigingen nog niet in de update-pop-up stonden
        # (bijv. omdat Seren zelf al automatisch heeft bijgewerkt).
        already_shown = parse_version(state.get("notified")) == parse_version(installed)
        if (parse_version(installed) == remote_v and not already_shown
                and get_bool("show_whats_new", True)):
            show_whats_new(latest)
        state["seen"] = installed
        state["notified"] = latest["version"]
    save_state(state)


def run_test():
    """Toont de update-pop-up zoals gebruikers hem zien, zonder iets op te slaan."""
    latest = fetch_latest()
    if latest is None:
        xbmcgui.Dialog().ok(HEADING, "GitHub is nu niet bereikbaar.\nProbeer het later nog eens.")
        return
    installed = find_installed_version()
    xbmcgui.Dialog().notification(
        HEADING,
        "Thema gevonden: %s" % installed if installed else "Thema niet gevonden in Seren",
        xbmcgui.NOTIFICATION_INFO, 4000)
    xbmc.sleep(1500)
    show_update_available(latest, "0.0.0 (test)", test=True)
